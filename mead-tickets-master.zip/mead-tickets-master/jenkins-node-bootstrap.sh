#!/bin/sh
# this script installs various jenkins prereqs - this really should be done in Ansible

SVN=1.14.2
GIT=2.36.1

uname -a | grep -iq el7 || exit 1

NATIVE="openssl-devel \
rerun \
xmlstarlet \
xz-devel \
tk-devel \
readline-devel \
bzip2-devel \
libffi-devel \
jsch "

WSGC="
wsgc-devops-toolchain-ci-tools \
wsgc-devops-toolchain-scm-tools \
wsgc-devops-rerun-module-jenkins \
wsgc-devops-rerun-module-wsgc-jenkins \
wsgc-devops-rerun-module-artifactory \
wsgc-devops-rerun-module-endeca \
wsgc-devops-rerun-module-wsgc-maven-release \
wsgc-devops-toolchain-build-support-maven-config-snapshots \
wsgc-devops-toolchain-build-support-python-setuptools \
wsgc-jdk8-ci-1-172.x86_64 \
"

sudo yum -y install $NATIVE -d0

sudo yum -y remove wsgc-devops-toolchain-python3 -d0

sudo /usr/bin/yum -y '--disablerepo=*' '--enablerepo=wsgc-*' install wsgc*rpm -d1

sudo /usr/bin/yum -y '--disablerepo=*' '--enablerepo=wsgc-*' install $WSGC -d1

SVN_LIST=$(curl -fsqk https://artifactory.wsgc.com/artifactory/ext-release-local/com/subversion/centos7/ | grep "subversion.*$SVN.*rpm" | tail -1 | awk -F '[<>]' '{ print $3 }')
rm -f subversion*rpm
curl -fsqk -O https://artifactory.wsgc.com/artifactory/ext-release-local/com/subversion/centos7/$SVN_LIST

GIT_LIST=$(curl -fsqk https://artifactory.wsgc.com/artifactory/ext-release-local/com/git/git2u/$GIT/ | grep "href=.*git2u.*rpm" | awk -F '[<>]' '{ print $3 }')

for pkg in $GIT_LIST
do
  URL=https://artifactory.wsgc.com/artifactory/ext-release-local/com/git/git2u/$GIT/$pkg
  [[ -e $pkg ]] || curl -fsqk -O $URL
done

sudo yum -y remove subversion git git2u\* -d1
sudo yum -y install git2u* -d1

#subversion-perl-1.7.14-16.el7.x86_64
#subversion-libs-1.7.14-16.el7.x86_64
sudo rpm -e subversion --nodeps
sudo yum -y install subversion-$SVN*.rpm

rpm -qa | grep -i wsgc | sort 

exit 0
