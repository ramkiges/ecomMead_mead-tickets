#!/bin/sh
PATH=/usr/local/bin:/apps/mead-tools:/bin:/sbin:/usr/bin:/usr/sbin:~/bin
OUT=hostlist.txt

rm -f $OUT
for e in bpv uat1 uat2 uat2 uat3 uat4 uat5 uat6 uat7 uat8 cabpv cauat1 cauat2 cauat3 cauat4 cauat6 cauat7 
do
  for b in $(getbrandlist $e)
  do
    host=$(gethost $b $e)
    [[ -z $host ]] && continue
    dns=$(host $host | grep -i address | awk '{ print $1 }' | awk -F\. '{ print $1 }')

    echo "${host}   $dns" | tee -a $OUT
  done
done

git add $OUT
