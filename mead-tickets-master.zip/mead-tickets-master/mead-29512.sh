#!/bin/sh

#jenkins-jnlp build -s eCommerce-DevOps/job/wsgc-apmagents/job/release/

jenkins-jnlp build -s eCommerce-DevOps/job/contentprocessor-common-config/job/release/

#for e in dev qa1 qa2 qa4 qa5 qa7 rgs rgs2 rgs3 uat1 uat2 perf ca1
for e in rgs2
do
  jenkins-jnlp build -s eCommerce-DevOps/job/contentprocessor-$e-config/job/release/
  jenkins-jnlp build -s deploy-contentprocessor-nonprod -p Env=$e
done

