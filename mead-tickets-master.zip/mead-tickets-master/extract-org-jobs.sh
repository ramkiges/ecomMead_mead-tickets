#!/bin/sh
# extract the list of jobs from a Jenkins org

#VIEW=https://ecombuild.wsgc.com/jenkins/job/International-Bedrock/
#VIEW=https://ecombuild.wsgc.com/jenkins/view/GHE%20Orgs/job/Platform-Application/
#VIEW=https://ecombuild.wsgc.com/jenkins/view/GHE%20Orgs/job/Platform-Data/
VIEW=https://ecombuild.wsgc.com/jenkins/view/GHE%20Orgs/job/Enterprise-Services/
#VIEW=https://ecombuild.wsgc.com/jenkins/view/GHE%20Orgs/job/eCommerce-Bedrock/
#VIEW=https://ecombuild.wsgc.com/jenkins/view/GHE%20Orgs/job/Esre-Bedrock/

VIEW=$(echo "$VIEW" | sed -es%/$%%g)
ORG=$(echo "$VIEW" | awk -F/ '{ print $NF }')

for job in $(curl -fsqk "$VIEW/" | sed -es/\"//g -es/'<a href=job'/'\n<a href=job'/g | grep "a href=job/" | awk -F/ '{ print $2 }' | sort -u)
do
  job=$ORG/job/$job
  list="$job, $list"
done

echo "$list"
