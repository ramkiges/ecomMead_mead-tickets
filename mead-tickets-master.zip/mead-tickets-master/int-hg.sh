#!/bin/sh

rm -f $HOME/Downloads/int-hg*

for b in $(getbrandlist)
do
  LIST=$HOME/Downloads/int-hg.txt
  for e in int3 int3 int5 
  do    
    n=$(gethost $b $e)
    [[ -z $n ]] && continue
    h=$(host $n | grep -i address | awk '{ print $1 }')
    [[ -z $h ]] && continue
    echo "$b $n $h" >> $LIST
  done

  LIST=$HOME/Downloads/int-hg-ca.txt
  for e in caint3 caint4 caint4 caint5
  do    
    n=$(gethost $b $e)
    [[ -z $n ]] && continue
    h=$(host $n | grep -i address | awk '{ print $1 }')
    [[ -z $h ]] && continue
    echo "$b $n $h" >> $LIST
  done
done

