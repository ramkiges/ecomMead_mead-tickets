#!/bin/sh

LOC=com/microsoft/azure/azure-cli
cd /tmp

RPM=$(curl -sq https://packages.microsoft.com/yumrepos/azure-cli/ | awk -F '[<>]' '{ print $3 }' | grep "el7" | grep rpm | sort -V | tail -1)
URL=https://packages.microsoft.com/yumrepos/azure-cli/$RPM
SCRIPT=install-azure-cli.sh

curl -sq -O $URL || exit 1
curl -sq -O https://packages.microsoft.com/keys/microsoft.asc || exit 1

artifact-upload $0 $LOC
artifact-upload microsoft.asc $LOC
#artifact-upload $RPM $LOC
artifact-upload azure-cli.repo $LOC

cat > $SCRIPT << EOF
#!/bin/sh
# $SCRIPT
# installs azure-cli RPM
# RPM=$RPM

cd /tmp
curl -sq -O https://artifactory.wsgc.com/artifactory/ext-release-local/$LOC/$(basename $0) || exit 1
curl -sq -O https://artifactory.wsgc.com/artifactory/ext-release-local/$LOC/$RPM || exit 1
sudo yum -y install /tmp/$RPM -d1

EOF

chmod 755 $SCRIPT
artifact-upload $SCRIPT $LOC

exit 0

