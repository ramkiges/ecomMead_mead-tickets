#!/bin/sh
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)
for file in *qa31* *qa54*
do
  info=$(echo $file | awk -F- '{ print $6 }' | tr 'A-Z' 'a-z' | sed -es/\.txt//g)
  #echo "info:$info"
  env="${info:0:4}"
  brand="${info:4:2}"

  [[ $brand =~ ca ]] && { env="ca$env}"; brand=$(sed -es/ca//g <<< $brand); }
  
  dos2unix $file
  key=$(cat $file)
  echo "> $brand $env"
  /apps/mead-tools/jenkins-jnlp build update-apple-dev-cert -p Ticket=$TICKET -p Brand=$brand -p Environment=$env -p Restart=true -p \"Key=$key\"  
done
