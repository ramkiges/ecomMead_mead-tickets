#!/bin/sh
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)
for file in *QA31*
do
  env=$(echo $file | awk -F- '{ print $6 }' | tr 'A-Z' 'a-z')
  brand=$(echo $file | awk -F- '{ print $7 }' | tr 'A-Z' 'a-z' | sed -es/\.txt//g)

  [[ $brand =~ ca ]] && { env="ca$env}"; brand=$(sed -es/ca//g <<< $brand); }
  
  dos2unix $file
  key=$(cat $file)
  echo "> $brand $env"
  /apps/mead-tools/jenkins-jnlp build update-apple-dev-cert -p Ticket=$TICKET -p Brand=$brand -p Environment=$env -p Restart=true -p \"Key=$key\"  
done
