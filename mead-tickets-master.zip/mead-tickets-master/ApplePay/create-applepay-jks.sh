#!/bin/sh

JKS=applepay_keystore.jks
DATE=$(date +'%Y%m%d')
APPLEPAY=apple-pay-gateway-cert.apple.com

echo | openssl s_client -servername $APPLEPAY -connect $APPLEPAY:443 2>&1 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > apple-gateway.pem

#openssl x509 -inform der -in apple_pay.cer -out apple_pay.pem
#openssl x509 -inform der -in merchant_id.cer -out merchant_id.pem

#rm -f $JKS
#keytool -noprompt -storepass applepay -importcert -file merchant_id.cer -keystore $JKS -alias AppleMerchantID-$DATE
#keytool -noprompt -storepass applepay -importcert -file apple_pay.cer -keystore $JKS -alias ApplePay-$DATE
#keytool -noprompt -storepass applepay -importcert -file apple-gateway.pem -keystore $JKS -alias ApplePayGateway-$DATE

#git add apple_pay.* merchant_id.* apple-gateway.pem $JKS

keytool -storepass applepay -v -list -keystore $JKS

#svn up $(cat ~/.wsi_settings)/application/frontend-2.1/qa/config/app/trunk
#cp $JKS $(cat ~/.wsi_settings)/application/frontend-2.1/qa/config/app/trunk/src/main/resources/tomcat/conf
#svn status $(cat ~/.wsi_settings)/application/frontend-2.1/qa/config/app/trunk/src/main/resources/tomcat/conf
#svn commit -m "[DEVOPS] create new $JKS" $(cat ~/.wsi_settings)/application/frontend-2.1/qa/config/app/trunk/src/main/resources/tomcat/conf

# rebuild frontend config
ssh -q -tt ecombuild "/apps/mead-tools/jenkins-jnlp build wsgc-devops-frontend21-common"
sleep 5
ssh -q -tt ecombuild "/apps/mead-tools/jenkins-jnlp build wsgc-devops-frontend21-qa-app-config"
sleep 5
for BRAND in mg pb pk pt we ws
do
  ssh -q -tt ecombuild "/apps/mead-tools/jenkins-jnlp build wsgc-devops-frontend21-qa-$BRAND-app-config </dev/null &" 
  sleep 5
done

