#!/bin/sh
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:~/dse/bin

HOST=cassandra-qa1-rk1.wsgc.com
LOGIN="-u cassandra -p cassandra"

cql="create table domain_items_by_item_id ( item_id text, list_id text, item_key text, domain text, list_external_id text, primary key (item_id, list_id, item_key, domain) );"
echo "$cql"

echo "$cql" | cqlsh $LOGIN --cqlversion=3.4.4 $HOST
echo

