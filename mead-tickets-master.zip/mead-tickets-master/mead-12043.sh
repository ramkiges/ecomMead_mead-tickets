#!/bin/sh
# this script is for setting up Akamai in a frontend environment
# creates 2 CSV files:
# $TICKET-cnames.csv - submit to get CNAMES created
# $TICKET-vips.csv - submit to get VIPS created

ENV_LIST="qa36"
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)

CNAMES=/wsgc/mead-tickets/$TICKET-cnames.csv
VIPS=/wsgc/mead-tickets/$TICKET-vips.csv
rm -f $CNAMES $VIPS

echo "Please create the following CNAMEs in DNS" > $CNAMES
echo "Jira: $TICKET" >> $CNAMES
echo >> $CNAMES

for env in $ENV_LIST
do
    for b in mg pb pk pt we ws
    do
        domain=$(getdomain $b)            
        echo "www.$env.$domain,IN CNAME,secure-qa1.wsgc.com.edgekey.net" >> $CNAMES
    done
done
echo >> $CNAMES

echo "Please create the following A records in DNS and VIPs on the F5 load balancers; you can model these on the existing QA VIPs" > $VIPS
echo "Jira: $TICKET" >> $VIPS
echo >> $VIPS

echo "A records/VIPS,,,Node,Ports" >> $VIPS
for env in $ENV_LIST
do
    for b in mg pb pk pt we ws
    do
        domain=$(getdomain $b)            
        host=$(get-host $b $env)
        #ip=$(host $(get-host $b $env) | awk '{ print $NF }')
        echo "vip_${env}_${b}, IN A, origin-www.$env.$domain,$host, 80 49446" >> $VIPS
    done
done
echo >> $VIPS

git add $0 $CNAMES $VIPS

