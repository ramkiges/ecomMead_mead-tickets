import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxFactory
import javax.management.remote.JMXServiceURL as JmxUrl

def host = "mg-intdev1-rk1.wsgc.com"
def jmxPort = 39667

def serverUrl = 'service:jmx:rmi:///jndi/rmi://' + host + ':' + jmxPort + '/jmxrmi'
def server = JmxFactory.connect(new JmxUrl(serverUrl)).MBeanServerConnection

// Use JMX to pull the Catalina/Tomcat Environment
def query = new ObjectName('Catalina:type=Environment,*')
def beans = server.queryMBeans(query,null)
println "hello world"
def jndiValues = [:]
beans.each { bean ->
    jndiValues.put(bean.getObjectName().getKeyPropertyList().get('name'), server.getAttribute(bean.getObjectName(), 'value'))
}
