#!/bin/sh

HOST=cassandra-dev1-rk1

#cqlsh --cqlversion=3.4.4 $HOST << EOF
#use wsi_user_identity;
#CREATE TABLE IF NOT EXISTS persistent_refresh_token_details (
#refresh_token_id text,
#create_time timeuuid,
#expire_time timeuuid,
#authentication blob,
#refresh_token_details blob,
#datacenter text,
#primary key(refresh_token_id)
#) WITH COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'DAYS', 'compaction_window_size': 7};
#EOF

#cqlsh --cqlversion=3.4.4 $HOST << EOF
#use wsi_user_identity;
#CREATE TABLE IF NOT EXISTS principal_to_persistent_refresh_tokens (
#principal text, //The Principal involved in the token grant
#client_id text, //The OAUTH Client ID involved in the token grant
#create_time timeuuid, //The instant in which the token was created
#expire_time timeuuid, //The instant in which the token will expire
#refresh_token_id text, //The Globally Unique ID for the refresh token
#refresh_token_details blob, //The detailed object for the refresh token
#datacenter text, //The DC in which the token was created
#primary key((principal), client_id, create_time)
#) WITH CLUSTERING ORDER BY (client_id ASC,create_time DESC)
#AND COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'DAYS', 'compaction_window_size': 1} ;
#EOF

#cqlsh --cqlversion=3.4.4 $HOST << EOF
#use wsi_user_identity;
#CREATE TABLE IF NOT EXISTS principal_to_access_tokens (
#principal text, //The Principal involved in the token grant
#client_id text, //The OAUTH Client ID involved in the token grant
#create_time timeuuid, //The instant in which the token was created
#expire_time timeuuid, //The instant in which the token will expire
#access_token_id text, //The Globally Unique ID for the access token
#access_token_details blob, //The detailed object for the refresh token
#primary key((principal), client_id, create_time)
#) WITH CLUSTERING ORDER BY (client_id ASC,create_time DESC) 
#AND COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'MINUTES', 'compaction_window_size': 10} ;
#EOF


#cqlsh --cqlversion=3.4.4 $HOST << EOF
#use wsi_user_identity;
#ALTER TABLE wsi_user_identity.oauth_client_details ADD access_token_config text;
#ALTER TABLE wsi_user_identity.oauth_client_details ADD refresh_token_config text;
#ALTER TABLE wsi_user_identity.oauth_client_details ADD active_directory_role_groups text;
#
#ALTER TABLE wsi_user_identity.access_token_details ADD create_time timeuuid;
#ALTER TABLE wsi_user_identity.access_token_details ADD expire_time timeuuid;
#ALTER TABLE wsi_user_identity.access_token_details ADD datacenter text;
#
#ALTER TABLE refresh_token_details ADD create_time timeuuid;
#ALTER TABLE refresh_token_details ADD expire_time timeuuid;
#ALTER TABLE refresh_token_details ADD datacenter text;
#EOF

cqlsh --cqlversion=3.4.4 $HOST < update_oauth_client_details.cql

