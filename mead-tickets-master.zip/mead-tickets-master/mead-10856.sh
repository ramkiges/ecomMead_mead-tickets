#!/bin/sh

cqlsh --cqlversion=3.4.4 cassandra-dev1-rk2.wsgc.com << EOF
use wsi_user_identity;
CREATE TABLE IF NOT EXISTS persistent_refresh_token_details (
refresh_token_id text,
create_time timeuuid,
expire_time timeuuid,
authentication blob,
refresh_token_details blob,
datacenter text,
primary key(refresh_token_id)
) WITH COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'DAYS', 'compaction_window_size': 7};
EOF

cqlsh --cqlversion=3.4.4 cassandra-dev1-rk2.wsgc.com << EOF
use wsi_user_identity;
CREATE TABLE IF NOT EXISTS principal_to_persistent_refresh_tokens (
principal text, 
client_id text, 
create_time timeuuid, 
expire_time timeuuid, 
refresh_token_id text, 
refresh_token_details blob, 
datacenter text, 
primary key((principal), client_id, create_time)
) WITH CLUSTERING ORDER BY (client_id ASC,create_time DESC)
AND COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'DAYS', 'compaction_window_size': 1} ;
EOF

cqlsh --cqlversion=3.4.4 cassandra-dev1-rk2.wsgc.com << EOF
use wsi_user_identity;
CREATE TABLE IF NOT EXISTS principal_to_access_tokens (
principal text, 
client_id text, 
create_time timeuuid, 
expire_time timeuuid, 
access_token_id text, 
access_token_details blob, 
primary key((principal), client_id, create_time)
) WITH CLUSTERING ORDER BY (client_id ASC,create_time DESC) 
AND COMPACTION = {'class': 'TimeWindowCompactionStrategy', 'compaction_window_unit': 'MINUTES', 'compaction_window_size': 10} ;
EOF


cqlsh --cqlversion=3.4.4 cassandra-dev1-rk2.wsgc.com << EOF
use wsi_user_identity;
ALTER TABLE wsi_user_identity.oauth_client_details ADD access_token_config text;
ALTER TABLE wsi_user_identity.oauth_client_details ADD refresh_token_config text;
ALTER TABLE wsi_user_identity.oauth_client_details ADD active_directory_role_groups text;

ALTER TABLE wsi_user_identity.access_token_details ADD create_time timeuuid;
ALTER TABLE wsi_user_identity.access_token_details ADD expire_time timeuuid;
ALTER TABLE wsi_user_identity.access_token_details ADD datacenter text;

ALTER TABLE refresh_token_details ADD create_time timeuuid;
ALTER TABLE refresh_token_details ADD expire_time timeuuid;
ALTER TABLE refresh_token_details ADD datacenter text;
EOF

