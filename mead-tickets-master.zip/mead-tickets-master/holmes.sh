#!/bin/sh

cd ~/wsgc/toolchain-resource-model/src/main/resources/wsgc
git pull

TMP=/tmp/$(basename $0).txt
rm -f $TMP

LIST="dparck-vicn034 dparck-vicn037 dparck-vicn041 dparck-vicn048 dparck-vicn050 dparck-vicn051 dparck-vicn052 dparck-vicn088 dparck-vicn089 dparck-vicn090 dparck-vicn091 dparck-vicn092 dparck-vicn093 dparck-vicn094 dparck-vicn095 dparck-vicn096 dparck-vicn097 dparck-vicn098 dparck-vicn099 dparck-vicn100 dparck-vicn101 dparck-vicn102 dparck-vicn103 dparck-vicn104 dparck-vicn105 dparck-vicn106 dparck-vicn107 dparck-vicn108 dparck-vicn109 dparck-vicn110 dparck-vicn111 dparck-vicn112 dparck-vicn113 dparck-vicn114 dparck-vicn115 dparck-vicn116"

for host in $LIST
do
  cname=$(grep -irh $host .|awk -F\" '{ print $2 }' )
  brand=$(echo $cname | awk -F- '{ print $1 }')
  echo "$brand $host" >> $TMP
done

sort $TMP | awk '{ print $2, $1 }'
