#!/bin/sh

OUT=delphix-quota.txt
KUBE_CLUSTER=ts-sharedplatform-rck-nonprod
KUBE_CONTEXT="${KUBE_CLUSTER}_${LOGNAME}@wsgc.com"

kubectl config use-context $KUBE_CONTEXT >/dev/null 2>&1 || {
	echo "Unable to set context"
	exit 1
}

new=veqa2

#kubectl get namespace 2>/dev/null | grep -i vwebqa1 | awk '{ print $1 }'

#ns_list=$(kubectl get namespace 2>/dev/null | grep -i "ecommerce.*$new" | awk '{ print $1 }')
ns_list="ecommerce-ias-veqa2 ecommerce-inventory-service-veqa2 ecommerce-inventory-refresh-service-veqa2"

for ns in $ns_list; do
	echo "========================================"
	app=$(echo "$ns" | sed -es/-vwebqa1//g -es/-veqa1//g -es/-veqa2//g)

	#ref=$(kubectl get namespace 2>/dev/null | grep -i "^$app-" | egrep -vi "singleuse|intdev|delphix|vwebqa1|veqa|rj|uat6" | sort | awk '{ print $1 }' | tail -1)
	for target in uat; do
		ref=$(kubectl get namespace 2>/dev/null | grep -i "^$app-" | grep -i -- "-$target" | egrep -iv "singleuse|intdev|delphix|vwebqa1|veqa|rj|uat6" | sort | awk '{ print $1 }' | head -1)
		[[ -n $ref ]] && break
	done
	ref_name=$(echo $ref | sed -es/$app-//g)
	new_name=$new

	#echo "Reference: $ref_name"
	#kubectl -n $ref describe quota 2>/dev/null | egrep -iv "Name:"

	ref_mem=$(kubectl -n $ref describe quota 2>/dev/null | grep limits.memory | awk '{ print $NF }')
	ref_cpu=$(kubectl -n $ref describe quota 2>/dev/null | grep limits.cpu | awk '{ print $NF }')
	ref_pod=$(kubectl -n $ref describe quota 2>/dev/null | grep pods | awk '{ print $NF }')

	new_mem=$(kubectl -n $ns describe quota 2>/dev/null | grep limits.memory | awk '{ print $NF }')
	new_cpu=$(kubectl -n $ns describe quota 2>/dev/null | grep limits.cpu | awk '{ print $NF }')
	new_pod=$(kubectl -n $ns describe quota 2>/dev/null | grep pods | awk '{ print $NF }')

	#kubectl -n $ns describe quota 2>/dev/null | egrep -iv "Name:"

	echo "$app  $ns"
	echo "$ref_name     $ref_mem  $ref_cpu  $ref_pod"
	echo "$new_name     $new_mem  $new_cpu  $new_pod"

done >$OUT
