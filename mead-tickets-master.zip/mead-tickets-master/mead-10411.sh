#!/bin/sh

cd /wsgc/svn/devops/toolchain/node/prd/trunk
#svn up

brand=pb
new="18"

src=$(echo $new | awk '{ print $1 }')
src=$(expr $src - 1)
#src=3

for site in ab rk
do
	for n in $new
	do				
		[ -d "$brand-prd-${site}${n}v" ] && continue
		svn cp $brand-prd-${site}${src}v $brand-prd-${site}${n}v
		sed -es/${site}${src}/${site}${n}/g -i $brand-prd-${site}${n}v/pom.xml	
		echo
	done
done
