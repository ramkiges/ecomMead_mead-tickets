#!/bin/sh

RUNDECK=/Users/tfitzpatrick/wsgc/svn/rundeck/toolchain-resource-model/src/main/resources/wsgc
echo "server, hostname, rundeck-node"

for svr in $(cat cqservers.txt)
do
  host=$(host $svr | grep -i address | awk -F\. '{ print $1 }')
  [[ -z $host ]] && host="no dns"
  node=$(egrep -ir "$svr|$host" $RUNDECK | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)

  echo "$svr,$host,$node"
    
done
