#!/bin/sh
PATH=$PATH:~/dse/bin

KEYSPACE=wsi_user_identity_uat
TABLE=oauth_client_details
HOST=cassandra-uat1-rk1.wsgc.com
ROLE=ROLE_SESSION_RESOLVER

for b in MG PB PK PT WE WS
do

  #echo "describe keyspaces" | cqlsh --cqlversion=3.4.4 $HOST; exit
  #echo "describe keyspace $KEYSPACE" | cqlsh --cqlversion=3.4.4 $HOST > x; exit
  #echo "describe $KEYSPACE.$TABLE" | cqlsh --cqlversion=3.4.4 $HOST; exit

  Q="select authorities from $KEYSPACE.$TABLE where client_id = 'ecom_${b}/QA';"
  A=$(echo "$Q" | cqlsh --cqlversion=3.4.4 $HOST | grep "ROLE" | sed -es/' '//g)
  echo "$A" | grep -q "$ROLE" && continue
  echo "A: $A"
  [[ -z $A ]] && A="ROLE_DOMAIN_PUBLISHER_CLIENT,ROLE_OAUTH_CLIENT,ROLE_USERS_CLIENT,ROLE_LOYALTYACCOUNTS_GET,ROLE_LOYALTYACCOUNTS_CREATE,ROLE_LOYALTYACCOUNTS_UPDATE,ROLE_PROFILES_CLIENT"
  #continue

  U="UPDATE $KEYSPACE.$TABLE SET authorities = '$A,$ROLE' where client_id = 'ecom_${b}/UAT';"
  echo "$U"
  echo "$U" | cqlsh --cqlversion=3.4.4 $HOST
  echo
done

