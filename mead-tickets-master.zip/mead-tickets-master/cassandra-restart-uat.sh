#!/bin/sh
PATH=/apps/mead-tools:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:~/bin

MSG=
for x in 1 2 3
do
  for dc in sac rck
  do
    host="cas${dc}-vicn00$x"
    status=$(ssh -q -tt $host "sudo service wsgc-dse status" | grep -i "running")
    echo "$host: $status"
    MSG="$host: $status
$MSG"
    [[ $status =~ not ]] && ssh -q -tt $host "sudo service wsgc-dse restart"
  done
done

jenkins-jnlp build -s deploy-oauth-uat 

for jira in $*
do
  jira-label $jira "RestartCassandra"
  jira-label $jira "RestartOauth"
  jira-close -t $jira -c " (i) $(basename $0) UAT Cassandra and Oauth restarted 
$MSG"
done

