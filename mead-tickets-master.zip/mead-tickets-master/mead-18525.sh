cqlsh --cqlversion=3.4.4 cassandra-dev1-rk1.wsgc.com < mead-18525.cql
