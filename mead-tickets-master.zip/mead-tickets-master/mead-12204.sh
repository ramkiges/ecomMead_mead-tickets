#!/bin/sh
# this script is for setting up Akamai in a frontend environment
# creates 2 CSV files:
# $TICKET-cnames.csv - submit to get CNAMES created
# $TICKET-vips.csv - submit to get VIPS created

ENV_LIST=qa38
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)

BailOut() {
    [ -n "$1" ] && echo "$*"
    exit 1
}

[ -z "$ENV_LIST" ] && BailOut "ENV_LIST can't be blank"
CNAMES=/wsgc/mead-tickets/$TICKET-cnames.csv
VIPS=/wsgc/mead-tickets/$TICKET-vips.csv
rm -f $CNAMES $VIPS

DOMAINS="markandgraham.com potterybarn.com potterybarnkids.com pbteen.com westelm.com williams-sonoma.com"

git add $0

echo "Please create the following CNAMEs in DNS" > $CNAMES
echo "Jira: $TICKET" >> $CNAMES
echo >> $CNAMES

for env in $ENV_LIST
do
    for domain in $DOMAINS
    do
        b=$(getbrand $domain)            
        echo "www.$env.$domain,IN CNAME,secure-qa1.wsgc.com.edgekey.net" >> $CNAMES
    done
done
echo >> $CNAMES

echo "Please create the following A records in DNS and VIPs on the F5 load balancers; you can model these on the existing QA VIPs" > $VIPS
echo "Jira: $TICKET" >> $VIPS
echo >> $VIPS

echo "A records/VIPS,,,Node,Ports" >> $VIPS
for env in $ENV_LIST
do
    for domain in $DOMAINS
    do
        b=$(getbrand $domain)            
        host=$(get-host $b $env)
        [ -z "$host" ] && BailOut "CNAME not found for $b $env"
        #ip=$(host $(get-host $b $env) | awk '{ print $NF }')
        echo "vip_${env}_${b}, IN A, origin-www.$env.$domain,$host, 80 49446" >> $VIPS
    done
done
echo >> $VIPS

git add $CNAMES $VIPS
git commit -a -m "[$TICKET] commit CNAME and VIP request files"

jira-comment $TICKET "{noformat:title=CNAMEs for $ENV_LIST}$(cat $CNAMES){noformat}"
jira-comment $TICKET "{noformat:title=VIPs for $ENV_LIST}$(cat $VIPS){noformat}"

