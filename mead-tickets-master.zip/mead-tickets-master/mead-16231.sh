#!/bin/sh
# https://github.wsgc.com/eCommerce-DevOps/docker-base
#NOTE: they/we need to test the new one before pushing it out there, with more than one of the repos that use this pipeline, because the last time someone did this it broke bedrock builds because one of the new dependencies wasn't backward-compatible
CIUSER=$(cat $HOME/.ciuser)
TAG=$(basename $0 | sed -es/\.sh//g)
DATE=$(date +'%Y%m%d%H%M')

# Testing can be done by searching for this pipeline in eCommerce-Bedrock (search in GHE for "plumber('WebComponentJest')" in bedrock) and push a fork of the current release branch of a few of the repos that seem different enough to a team org, using a branch of pipeline-commons that uses your tag of the wct-ram-jest container, and making sure they build

#REPO=git@github.wsgc.com:eCommerce-DevOps/docker-base.git
#BRANCH=release
#TMP=/wsgc/svn/docker-base

REPO=git@github.wsgc.com:eCommerce-Tahoe/docker-base.git
BRANCH=tah-3403-wct-ram-jest-python3
TMP=/wsgc/svn/tah/docker-base

#if [ "$1" = "clean" -o ! -d "$TMP" ]
#then
#  rm -rf $TMP
#  git clone $REPO $TMP
#fi

cd $TMP

git fetch --all >/dev/null 2>&1
git pull --all >/dev/null 2>&1
git branch --all >/dev/null 2>&1
[ -n "$BRANCH" ] && { git checkout $BRANCH; git pull; }

./download
./generate_secrets

set -x
docker tag docker-dev.wsgc.com/wct-ram-jest:$TAG docker-dev.wsgc.com/wct-ram-jest:$TAG-$DATE
docker rmi docker-dev.wsgc.com/wct-ram-jest:$TAG

time docker build -t wsgc/wct-ram-jest:$TAG -f docker/wct-ram-jest/Dockerfile docker/wct-ram-jest
time docker build -t docker-dev.wsgc.com/wct-ram-jest:$TAG -f docker/wct-ram-jest/Dockerfile docker/wct-ram-jest
time docker image push docker-dev.wsgc.com/wct-ram-jest:$TAG

set +x

docker image list | grep -i wct-ram-jest

# copy `current` to safe place and copy ours to `current`
echo docker tag docker-dev.wsgc.com/wct-ram-jest:current docker-dev.wsgc.com/wct-ram-jest:current-$DATE
echo docker rmi docker-dev.wsgc.com/wct-ram-jest:current

echo docker build -t docker-dev.wsgc.com/wct-ram-jest:current -f docker/wct-ram-jest/Dockerfile docker/wct-ram-jest
echo docker image push docker-dev.wsgc.com/wct-ram-jest:current

