#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/apps
echo "this has been moved to a RunDeck job"
exit 1

if [ -z "$1" ]
  then
    echo "Please enter the EDAM Version to be deployed, argument=edam version"
    exit 1
fi

# Common Variables 
HTTPRESPONSE="json"
SUCCESS="success"

BASE_URL="https://artifactory.wsgc.com/artifactory/wsgc-releases/com/wsgc/ecommerce"
APP=edam
PROJECT=edam.ui.apps
ARTIFACT_VERSION=$1
HOST="localhost"
PORT=4501
PROTOCOL="http://"
USER="admin"
PASSWORD="admin"
ARTIFACT_NAME=$PROJECT-$ARTIFACT_VERSION.zip
ARTIFACT_URL=$BASE_URL/$APP/$PROJECT/$ARTIFACT_VERSION/$ARTIFACT_NAME

echo "Artifact url to download ==>  $ARTIFACT_URL " 

function validate_artifact(){
  if [[ `wget -S --spider --no-check-certificate $1  2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
    echo " Artifact URL looks good"
  else
    echo " Some issue with the artifact url, please check the version / artifact exists"
    exit 1
  fi
}

validate_artifact $ARTIFACT_URL

cd /tmp
rm -rf $ARTIFACT_NAME*

wget -bq --no-check-certificate $ARTIFACT_URL

sleep 10 

[ -f $ARTIFACT_NAME ] && echo "Downloaded artifact exist, we are good to upload and install " || { echo "Some issue with download" && exit1; }

##### Upload and install to AEM ######

echo " Start - Upload and install package to AEM Server "

curl -u $USER:$PASSWORD -F file=@"$ARTIFACT_NAME" -F name="$ARTIFACT_NAME" -F force=true -F install=true http://$HOST:$PORT/crx/packmgr/service.jsp 2>&1 
