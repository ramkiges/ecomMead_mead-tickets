#!/bin/sh
# this script is for setting up Akamai in a frontend environment
# creates 2 CSV files to be submitted in SNOW tickets:
# $TICKET-cnames.csv - submit to get CNAMES created
# $TICKET-vips.csv - submit to get VIPS created

ENV_LIST="uat1"
TLD="com"
# secure-qa to get a legit cert, secure-qa1 for everything else
# secure-qa2.wsgc.com.edgekey.net for canada
AKAMAI=secure-qa1
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)

BailOut() {
    [ -n "$1" ] && echo "$*"
    exit 1
}

[ -z "$ENV_LIST" ] && BailOut "ENV_LIST can't be blank"
CNAMES=$TICKET-cnames.csv
VIPS=$TICKET-vips.csv
rm -f $CNAMES $VIPS

DOMAINS="rejuvenation.$TLD"

git add $0

echo "Please create the following CNAMEs in DNS" > $CNAMES
echo >> $CNAMES

for env in $ENV_LIST
do
    akenv=$env
    for domain in $DOMAINS
    do
        b=$(getbrand $domain)            
        tld=$(echo $domain | awk -F\. '{ print $NF }')
        [[ $tld = "ca" ]] && akenv=$(echo "$akenv" | sed -es/"^ca"//g)
        echo "www.$akenv.$domain,IN CNAME,$AKAMAI.wsgc.com.edgekey.net" >> $CNAMES
    done
done
echo >> $CNAMES
echo "Jira: $TICKET" >> $CNAMES
echo >> $CNAMES

echo "Please create the following 'A' records in DNS, and corresponding VIPs on the F5 load balancers. 
You can model these on the existing QA VIPs.  
Please use the TCP 'Sitecode_ignore' node health rule for these VIPs" > $VIPS
echo >> $VIPS

echo "A records/VIPS,,,Node,Ports" >> $VIPS
for env in $ENV_LIST
do
    akenv=$env
    for domain in $DOMAINS
    do
        b=$(getbrand $domain)            
        host=$(get-host $b $env)
        [ -z "$host" ] && BailOut "CNAME not found for $b $env"

        tld=$(echo $domain | awk -F\. '{ print $NF }')
        [[ $tld = "ca" ]] && akenv=$(echo "$akenv" | sed -es/"^ca"//g)
        #ip=$(host $(get-host $b $env) | awk '{ print $NF }')

        echo "vip_${akenv}_${b}_${tld}, IN A, origin-www.$akenv.$domain,$host, 80 49446" >> $VIPS
    done
done
echo >> $VIPS
echo "Jira: $TICKET" >> $VIPS
echo >> $VIPS

echo $CNAMES $VIPS
git add $CNAMES $VIPS $0
git commit -a -m "[$TICKET] commit CNAME and VIP request files"
git push

jira-comment $TICKET "{noformat:title=CNAMEs for $ENV_LIST}$(cat $CNAMES){noformat}"
jira-comment $TICKET "{noformat:title=VIPs for $ENV_LIST}$(cat $VIPS){noformat}"

