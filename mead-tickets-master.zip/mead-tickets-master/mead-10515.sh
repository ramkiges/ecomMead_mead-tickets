# this was a little script to create an emergency backdated war release
# this must be run on scm-tools-prd-rk as mavenbuild

TICKET=MEAD-10515
REALM=$(getversion wsgc-devops-frontend-prd-config-app)
RELEASE=havana
BASELOGIC=$(getversion baselogic $RELEASE)
BASELOGIC_BRANCH=$(echo $BASELOGIC | awk -F. '{sub($NF,"x");print}')

SITES=$(getversion mg $RELEASE)
SITES_BRANCH=$(echo $SITES | awk -F. '{sub($NF,"x");print}')

cd ~/mavenrelease

echo ./mvnrelease1.8 publish git@github.wsgc.com:eCommerce-Bedrock/dp-baselogic.git#branch/release-$BASELOGIC_BRANCH final '--reason=[RELEASE][$TICKET]'
BASELOGIC=$(getversion baselogic $RELEASE)

echo rerun wsgc-maven-release-1.8: frontend-release --release-url git@github.wsgc.com:eCommerce-Bedrock/dp-sites.git#branch/release-$SITES_BRANCH --release-action publish --release-type final --baselogic-version $BASELOGIC --release-reason "[RELEASE,$TICKET]-$RELEASE"

echo ./mvnrelease1.8 --non-interactive publish https://repos.wsgc.com/svn/devops/application/frontend-2.1/prd/config/app/trunk/ final --depversion=frontend.realm.version=$REALM '--reason=[RELEASE,$TICKET]-$RELEASE'

