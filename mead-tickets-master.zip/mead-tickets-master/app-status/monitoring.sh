#!/bin/bash

INPUT=Ecom_Server_Inventory_v4.csv
IFS=","
i=1
while read Hostname Application Environment Endpoint_URL ServiceName
do
test $i -eq 1 && ((i=i+1)) && continue
echo "Server : $Hostname"
#echo "EndpointURL : $Endpoint_URL"
#echo "ServiceName : $ServiceName"
Server=$Hostname
EndpointURL=$Endpoint_URL
ServiceName=$ServiceName
service=java


#FRED="Hostname"
#component=${FRED%%-*}
#application=wsgc-tomcat-$component


ping -c1 $Server > /dev/null
if [ $? -eq 0 ]
then
   echo "Server is ONLINE"
else
    fnEmailNotify
fi


if [ $EndpointURL = "NA" ] ;
 then
   break
else
   http_code=`curl -o /dev/null --silent --head --write-out '%{http_code}\n' $EndpointURL`
   echo "Endpoint URL status $http_code"
fi


sudo -u tomcat ssh $Server << EOF 


is_running=`ps aux | grep -v grep | grep $service | wc -l | awk '{print $1}'`
echo "$is_running"
if [ '$is_running != "0"' ] ;
then

   echo "$service service is running"

fi


httpd_running=`ps aux | grep -v grep| grep -v "$0" | grep httpd | wc -l | awk '{print $1}'`

if [ '$httpd_running != "0"' ] ;
then
    echo "httpd service is running"
else
    sudo service httpd start
    sleep 10
    httpd_running=`ps aux | grep -v grep| grep -v "$0" | grep httpd | wc -l | awk '{print $1}'`

    if [ '$httpd_running != "0"' ] ;
    then
      echo "httpd service started successfully"
    else
      fnEmailNotify
    fi
fi


STATUS=`systemctl is-active tomcat.service`
if [ '$STATUS = "active"' ] ; 
then
   echo "tomcat service is running"
else 
   initd=`ls /etc/init.d/ | grep $ServiceName | wc -l | awk '{ print $1 }'`

    if [ $initd = "1" ] ;
    then
           startup=`ls /etc/init.d/ | grep $ServiceName`          
           echo "Starting service..."
           /etc/init.d/${startup} start
           sleep 5
       
           STATUS=`systemctl is-active tomcat.service`
           if [ '$STATUS  = "active"' ] ;
           then
             echo "Application started successfully" 
           else  
             fnEmailNotify
           fi  
     fi
fi


fnEmailNotify()
{
        echo "Mail Notification";
}

EOF
done < $INPUT
