#!/bin/sh
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:~/dse/bin

HOST=cassandra-qa1-rk1
LOGIN="-u cassandra -p cassandra"

#KEYSPACE=wsi_user_identity_uat

#cql="describe tables" 
#cql="SELECT * FROM "wsi_user_identity"."oauth_client_details" WHERE "client_id" = 'wmosQA' LIMIT 300;

cql="wsi_user_identity.update oauth_client_details set access_token_validity = 86400 where client_id = 'wmosQA';"

echo "$cql"


echo "$cql" | cqlsh $LOGIN --cqlversion=3.4.4 $HOST
echo

