#!/bin/sh
# https://confluence.wsgc.com/display/PdM/Set+Up+AEM+Environment
#
# script to do prod installs of AEM base package
# This was originally supposed to be a simple script to bootstrap the installation
# then along came the mother-of-all-scope-creep and now it's supposed to do everything except wash the windows and feed the cat
# this could really be done better in ansible but it's too late now
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin
SLEEP=5

# generic error and exit function
BailOut() {
    [ -n "$1" ] && echo "$*"
    echo "Usage: $(basename $0) <env> <role> <port> <alternate> <project>

    env:    dev/qa/uat/prod
    role:   primary or standby
    port:   tcp port for service
    IP:     IP/hostname of primary server
    project:  you should document your scripts better

Example:
# $(basename $0) uat primary 4501 192.168.75.165 edam-west
"
    exit 1
}

# these have to go together
AEM_JDK=wsgc-jdk8-172
JAVA_HOME=/apps/jdk1.8.0_172
export JAVA_HOME

PATH=$JAVA_HOME/bin:$PATH
export PATH

# parse arguments
AEM_INSTANCE=$(echo $1 | tr "A-Z" "a-z" | egrep -i "dev|qa|uat|prod|perf|rgs")
AEM_ROLE=$(echo $2 | tr "A-Z" "a-z" | egrep -i "primary|standby")
AEM_PORT=$3
AEM_IP=$4
AEM_PROJECT=$(echo $5 | egrep -i "edam-west|edam-east")
#AEM_PROJECT=$5

# verify arguments
[ -z "$AEM_INSTANCE" ] && BailOut "Need instance type"
[ -z "$AEM_ROLE" ] && BailOut "Need role"
[ -z "$AEM_PORT" ] && BailOut "Need port"
[ -z "$AEM_IP" ] && BailOut "Need primary host IP"
[ -z "$AEM_PROJECT" ] && BailOut "Need project \"$AEM_PROJECT\" is not valid"

sudo /usr/bin/yum -y --enablerepo=wsgc-* clean all -d1
sudo /usr/bin/yum -y --disablerepo=* --enablerepo=wsgc-* install $AEM_JDK -d1

# repos where the installation bits are staged
INSTALL_ZIP=https://artifactory.wsgc.com/artifactory/ext-release-local/com/adobe/aem/edam-aem-install/1.0/edam-aem-install-1.0.zip
AEM_REPO_JAR=https://artifactory.wsgc.com/artifactory/ext-release-local/com/adobe/AEM/6.5.2/AEM-6.5.2.jar
AEM_REPO_SP=https://artifactory.wsgc.com/artifactory/ext-release-local/com/adobe/AEM/6.5.2/AEM-6.5.2-SP2.zip

# allow java to use privileged ports
JLI=$(find $JAVA_HOME -name jli | head -1)
echo "Set $JAVA_HOME/bin/java to allow privileged ports ($JLI)"
setcap cap_net_raw+epi $JAVA_HOME/bin/java
grep -iq "$JLI" /etc/ld.so.conf.d/java.conf 2>/dev/null || echo "$JLI" >> /etc/ld.so.conf.d/java.conf
ldconfig

# AEM props
AEM_VERSION=6.5
APP_DIR=/apps/edam
AEM_PASS=admin
AEM_INIT=wsgc-cq
AEM_USER=tomcat
AEM_GROUP=webadmin
AEM_LOG="/var/log/weblogs/$(basename $APP_DIR)-$AEM_ROLE"
AEM_DIR=$APP_DIR/aem-$AEM_ROLE 
AEM_INIT="$AEM_INIT-$AEM_ROLE"

# some props are different prod vs nonprod
if [ "$AEM_INSTANCE" = "prod" ]
then
    # prod settings
    APM_HOST=apm.wsgc.com
    APM_KEY=489a5a83-4299-4206-911d-a07da97bbbfc
    AEM_HEAP=16384m
else
    # non-prod settings 
    #APM_HOST=apm-qa.wsgc.com
    APM_HOST=adyrck-vicn001.wsgc.com
    APM_KEY=97d46d42-6b3b-44c9-b11a-01bd372eda24
    AEM_HEAP=8192m
fi

[ "$AEM_ROLE" = "primary" ] && AEM_JMX=39667
[ "$AEM_ROLE" = "standby" ] && AEM_JMX=37667

# appdynamics props
APM_NAME=edam
APM_TIER=aem

# stop if it's already running
[ -e /etc/init.d/$AEM_INIT ] && /etc/init.d/$AEM_INIT stop >/dev/null 2>&1

# create appdynamics profile
mkdir -p /apps/apmagents/etc /var/log/weblogs/appdynamics
cat > /apps/apmagents/etc/profile << EOF
export APPDYNAMICS_HOME=/apps/apmagents
export APPDYNAMICS_USER=tomcat
export APPDYNAMICS_MACHINEAGENT_HOME=/apps/apmagents/machineagent
export APPDYNAMICS_APPAGENT_APPLICATIONNAME=$APM_NAME
export APPDYNAMICS_APPAGENT_TIERNAME=$APM_TIER
export APPDYNAMICS_CONTROLLER_HOSTNAME=$APM_HOST
export APPDYNAMICS_CONTROLLER_PORT=5443
export APPDYNAMICS_MACHINEAGENT=/apps/apmagents/machineagent/machineagent.jar
export APPDYNAMICS_JAVA=$JAVA_HOME/bin/java
export APPDYNAMICS_LOGDIR=/var/log/weblogs/appdynamics/appagent
export APPDYNAMICS_CONTROLLER_SSL_ENABLED=true
export APPDYNAMICS_AGENT_ACCOUNT_ACCESS_KEY=$APM_KEY
export APPDYNAMICS_AGENT_OPTIONS="-Dappdynamics.controller.hostName=\${APPDYNAMICS_CONTROLLER_HOSTNAME} -Dappdynamics.controller.ssl.enabled=\${APPDYNAMICS_CONTROLLER_SSL_ENABLED} -Dappdynamics.controller.port=\${APPDYNAMICS_CONTROLLER_PORT} -Dappdynamics.agent.applicationName=\${APPDYNAMICS_APPAGENT_APPLICATIONNAME} -Dappdynamics.agent.tierName=\${APPDYNAMICS_APPAGENT_TIERNAME} -Dappdynamics.agent.nodeName=\$(hostname --short) -Dappdynamics.agent.logs.dir=\${APPDYNAMICS_LOGDIR}/\$(hostname --short) -Dappdynamics.agent.accountAccessKey=\${APPDYNAMICS_AGENT_ACCOUNT_ACCESS_KEY} -Dappdynamics.agent.runtime.dir=\${APPDYNAMICS_LOGDIR}"
export APPDYNAMICS_JAVAAGENT_OPTIONS="-javaagent:/apps/apmagents/appagent/javaagent.jar -Dappdynamics.controller.hostName=\${APPDYNAMICS_CONTROLLER_HOSTNAME} -Dappdynamics.controller.ssl.enabled=\${APPDYNAMICS_CONTROLLER_SSL_ENABLED} -Dappdynamics.controller.port=\${APPDYNAMICS_CONTROLLER_PORT} -Dappdynamics.agent.applicationName=\${APPDYNAMICS_APPAGENT_APPLICATIONNAME} -Dappdynamics.agent.tierName=\${APPDYNAMICS_APPAGENT_TIERNAME} -Dappdynamics.agent.nodeName=\$(hostname --short) -Dappdynamics.agent.logs.dir=\${APPDYNAMICS_LOGDIR}/\$(hostname --short) -Dappdynamics.agent.accountAccessKey=\${APPDYNAMICS_AGENT_ACCOUNT_ACCESS_KEY} -Dappdynamics.agent.runtime.dir=\${APPDYNAMICS_LOGDIR}"
EOF

# source appd profile
. /apps/apmagents/etc/profile

# CQ variables
CQ_RUNMODE="$AEM_ROLE"
CQ_LOGROTATE=/etc/logrotate.d/$AEM_INIT
CQ_CONF=/etc/httpd/conf.d/cq.conf
CQ_JVM_OPTS="-server \
-Xmx${AEM_HEAP} \
-Djava.awt.headless=true \
-Dcom.sun.management.jmxremote \
-Dcom.sun.management.jmxremote.port=$AEM_JMX \
-Dcom.sun.management.jmxremote.ssl=false \
-Dcom.sun.management.jmxremote.authenticate=false \
-XX:+UseG1GC \
-XX:+UseStringDeduplication \
-XX:+PrintGCApplicationConcurrentTime \
-XX:+PrintGCApplicationStoppedTime \
-XX:+PrintGCDateStamps \
-XX:+PrintGCDetails \
-XX:+PrintReferenceGC \
-XX:+PrintTenuringDistribution \
-XX:+PrintStringTableStatistics \
-XX:+HeapDumpOnOutOfMemoryError \
-XX:HeapDumpPath=/apps/edam/heapdump \
-Xloggc:$AEM_LOG/aem-gc.log \
-XX:GCLogFileSize=50M \
-XX:+UseGCLogFileRotation \
-XX:NumberOfGCLogFiles=10 \
-verbose:gc"

# 
CQ_JVM_OPTS="$CQ_JVM_OPTS"

# add appdynamics to CQ options
#CQ_JVM_OPTS="$CQ_JVM_OPTS $APPDYNAMICS_JAVAAGENT_OPTIONS"

# the name of this jar is important - it contains the version, run mode and port
AEM_JAR="aem${AEM_VERSION}-$CQ_RUNMODE-p${AEM_PORT}.jar"

# download install.zip
cd /tmp
echo "Fetching $INSTALL_ZIP"
curl -q -O -ks $INSTALL_ZIP || BailOut "Fetch failed"
mv $(basename $INSTALL_ZIP) install.zip
chmod 666 install.zip
unzip -uq /tmp/install.zip

# download jar file
echo "Fetching $AEM_REPO_JAR"
curl -q -O -ks $AEM_REPO_JAR || BailOut "Fetch failed"
mv $(basename $AEM_REPO_JAR) $AEM_JAR || BailOut "rename failed: $(basename $AEM_REPO_JAR) -> $AEM_JAR"
chmod 666 $AEM_JAR

# download service pack
echo "Fetching $AEM_REPO_SP"
curl -q -O -ks $AEM_REPO_SP || BailOut "Fetch failed"

# install zip and unzip and bc - bc is needed by apmagents
yum -y install zip unzip bc mod_ssl ImageMagick ImageMagick-devel -d1 
sudo cp aem-sRGB2014.icc /etc/ImageMagick-6/sRGB2014.icc

# install AEM_JDK
yum -y --disablerepo=\* --enablerepo=wsgc-\* install $AEM_JDK -d1 || BailOut "JDK installation failed ($AEM_JDK)"
[ -e $JAVA_HOME/bin/java ] || BailOut "JAVA_HOME ($JAVA_HOME) doesn't contain a java"

# install apm
yum -y --disablerepo=\* --enablerepo=wsgc-\* install wsgc-apmagents -d1 || BailOut "wsgc-apmagents installation failed"
chkconfig wsgc-machineagent on

# create installation directory
mkdir -p $AEM_DIR || BailOut "Failed to create $AEM_DIR"
chown -R $AEM_USER:$AEM_GROUP $AEM_DIR 

# create license file
cat > $AEM_DIR/license.properties << EOF
#CRX License Properties
#Thu Jul 16 22:10:05 PDT 2009
license.product.name=CRX
license.customer.name=wsi
license.product.version=1.4.2.20090324
license.downloadID=626d6cad-5c12-c04e-8596-1257896111d8
EOF

# copy jar to installation directory
cp /tmp/$AEM_JAR $AEM_DIR || BailOut "Failed to stage /tmp/$AEM_JAR to $AEM_DIR"

# unpack jar
cd $AEM_DIR
java -jar $AEM_JAR -unpack || BailOut "Unpack failed!"

# stage the install files from the zip file
cd $AEM_DIR/crx-quickstart
unzip -uq /tmp/install.zip || BailOut "Unzip failed"

# set ownership of directory
chown -R $AEM_USER:$AEM_GROUP $AEM_DIR

cd $AEM_DIR
echo "$AEM_PASS" | su -l tomcat -c "cd $AEM_DIR; java ${CQ_JVM_OPTS} -jar ${AEM_JAR} -r nosamplecontent,$AEM_INSTANCE,$AEM_PROJECT,$AEM_ROLE,crx3,crx3tar &"
ret=${PIPESTATUS[1]}
[ $ret -ne 0 ] && BailOut "Startup failed"

echo "Sleeping for $SLEEP for app to start "
sleep $SLEEP

# copy service pack to install
echo "Copy SP $(basename $AEM_REPO_SP) -> $AEM_DIR/crx-quickstart/install"
cp /tmp/$(basename $AEM_REPO_SP) $AEM_DIR/crx-quickstart/install

echo "Shutting down AEM"
cd $AEM_DIR/crx-quickstart/bin || BailOut "Can't cd to $AEM_DIR/crx-quickstart/bin"
./stop 
PID=$(ps -ef | grep "${AEM_JAR}" | egrep -iv "grep" | awk '{ print $2 }')
[ -n "$PID" ] && kill -9 $PID

# this is where it gets interesting: for standby mode, we need to copy a file from the alternate machine - why?
if [ "$AEM_ROLE" = "standby" ]
then
    echo "Copying crx-quickstart from primary ($AEM_IP)"
    if [ -d $APP_DIR/aem-primary/crx-quickstart ]
    then
set -x
        cp -r $APP_DIR/aem-primary/crx-quickstart $AEM_DIR
set +x
    else
set -x
        scp -r $AEM_IP:$APP_DIR/aem-primary/crx-quickstart $AEM_DIR
set +x
    fi

    echo "Remove sling.id.file"
set -x
    find $AEM_DIR/crx-quickstart -name sling.id.file -exec rm {} \;
set +x

    echo "Set primary service IP"
set -x
    sed -es/primary.host=".*"/primary.host=\"$AEM_IP\"/g \
        -i $AEM_DIR/crx-quickstart/install/install.standby/org.apache.jackrabbit.oak.segment.standby.store.StandbyStoreService.config
set +x
fi

# create init scripts
cat > /etc/init.d/$AEM_INIT << EOF
#!/bin/sh
# init script for $AEM_INIT $AEM_ROLE
# chkconfig: 35 99 99
JAVA_HOME=$JAVA_HOME
export JAVA_HOME

PATH=\$JAVA_HOME/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin
export PATH

# allow java to use privileged ports
setcap cap_net_raw+epi \$JAVA_HOME/bin/java
JLI=\$(find \$JAVA_HOME -name jli | head -1)
grep -iq "\$JLI" /etc/ld.so.conf.d/java.conf 2>/dev/null || echo "\$JLI" >> /etc/ld.so.conf.d/java.conf
ldconfig

# bring in the AppDynamics variables
.  /apps/apmagents/etc/profile

AEM_DIR=$AEM_DIR
AEM_ROLE=$AEM_ROLE
AEM_PORT=$AEM_PORT
CQ_PORT=\$AEM_PORT
AEM_JAR=$AEM_JAR
AEM_USER=$AEM_USER
AEM_GROOUP=$AEM_GROUP
AEM_PID=\$(ps -ef | egrep -i "\${AEM_JAR}|launchpad.*$AEM_PORT" | egrep -iv "grep" | awk '{ print \$2 }')
CQ_RUNMODE="author,nosamplecontent,$AEM_INSTANCE,$AEM_PROJECT,$CQ_RUNMODE"
CQ_HOME=$AEM_DIR/crx-quickstart
CQ_LOCK_FILE=wsgc-cq
APPDYNAMICS_JAVAAGENT_OPTIONS="${APPDYNAMICS_JAVAAGENT_OPTIONS}"
CQ_JVM_OPTS="${CQ_JVM_OPTS}"
#CQ_JVM_OPTS="\${CQ_JVM_OPTS} \${APPDYNAMICS_JAVAAGENT_OPTIONS}"
export CQ_JVM_OPTS
export LANG=C

aemStart() {
    echo "Starting \$AEM_INIT"
    #cp \$AEM_DIR/\$AEM_JAR \$CQ_HOME
    rm -f \$CQ_HOME/cq-quickstart*standalone-quickstart.jar
    chown -R \$AEM_USER:\$AEM_GROUP \$AEM_DIR
    su -l tomcat -c "cd \${CQ_HOME};  CQ_RUNMODE='\${CQ_RUNMODE}' CQ_PORT=\$CQ_PORT CQ_JVM_OPTS='\${CQ_JVM_OPTS}' JAVA_HOME=\${JAVA_HOME} PATH=\${PATH} \${CQ_HOME}/bin/start"
    ret=\$?

    netstat -a | grep -w \$AEM_PORT 
    ps -ef |grep -i java | egrep -iv "grep|\$\$"
    [ \$ret -eq 0 ] && touch /var/lock/subsys/\$CQ_LOCK_FILE
}

aemStop() {
    echo "Stopping \$AEM_INIT"
    su -l tomcat -c "cd \${CQ_HOME}/bin; JAVA_HOME=\${JAVA_HOME} PATH=\${PATH} \${CQ_HOME}/bin/stop"
    ret=\$?

    netstat -a | grep -w \$AEM_PORT 
    ps -ef |grep -i java | egrep -iv "grep|\$\$"
    [ \$ret -eq 0 ] && rm -f /var/lock/subsys/\$CQ_LOCK_FILE
    [ -n "\$AEM_PID" ] && kill \$AEM_PID
    ret=\$ret
}

aemStatus() {
    echo "Checking AEM service on port \$CQ_PORT"
    nc -z -w 5 -v 127.0.0.1 \$CQ_PORT </dev/null 
    ret=\$?

    ps -ef |grep -i java | egrep -iv "grep|\$\$"
}

case \$1 in
    start )
        aemStart
        service wsgc-machineagent restart
    ;;

    stop )
        aemStop
    ;;

    restart )
        aemStop
        sleep 5
        aemStart
        service wsgc-machineagent restart
    ;;

    status )
        aemStatus
    ;;

    * ) echo "Don't know what '\$1' is supposed to be"
        ret=1
    ;; 
esac

exit \$ret

EOF

#[ -e /etc/rc3.d/S99$AEM_INIT ] || ln -s /etc/init.d/$AEM_INIT /etc/rc3.d/S99$AEM_INIT
#[ -e /etc/rc3.d/K99$AEM_INIT ] || ln -s /etc/init.d/$AEM_INIT /etc/rc3.d/K99$AEM_INIT

chmod 755 /etc/init.d/$AEM_INIT
chkconfig --add $AEM_INIT
chkconfig $AEM_INIT on
chkconfig httpd on
chkconfig --list 2>/dev/null | grep $AEM_INIT
ps -ef | grep -i java | grep -i aem
netstat -a | grep -w $AEM_PORT 

cat > $CQ_CONF << EOF
# $CQ_CONF

#Listen 443
<VirtualHost *:443>
    SSLEngine on
    SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite DEFAULT:!EXP:!SSLv2:!DES:!IDEA:!SEED:+3DES
    SSLCertificateFile /etc/pki/tls/certs/localhost.crt
    SSLCertificateChainFile /etc/pki/tls/certs/localhost.crt
    SSLCertificateKeyFile /etc/pki/tls/private/localhost.key

    ServerName  $(hostname --fqdn):443
    ServerAlias $(hostname --short)
    ErrorLog logs/ssl_error_log
    TransferLog logs/ssl_access_log
    LogLevel warn

    DocumentRoot /var/www/html
    DirectoryIndex index.html  index.jsp
    ErrorLog "|/usr/sbin/rotatelogs /var/log/weblogs/httpd/solrwcm-error.log.%Y-%m-%d 86400"
    TransferLog "|/usr/sbin/rotatelogs /var/log/weblogs/httpd/solrwcm-access.log.%Y-%m-%d 86400"
    LogLevel warn
    <Files ~ "\.(cgi|shtml|phtml|php3?)$">
        SSLOptions +StdEnvVars
    </Files>
    <Directory "/var/www/cgi-bin">
        SSLOptions +StdEnvVars
    </Directory>
    SetEnvIf User-Agent ".*MSIE.*" \
        nokeepalive ssl-unclean-shutdown \
        downgrade-1.0 force-response-1.0
    CustomLog logs/ssl_request_log \
        "%t %h %{SSL_PROTOCOL}x %{SSL_CIPHER}x \"%r\" %b"

#    ProxyRequests       On
#    ProxyPreserveHost   On
#    ProxyPass           /   http://localhost:$AEM_PORT/
#    ProxyPassReverse    /   http://localhost:$AEM_PORT/
</VirtualHost>

Listen 38667
<VirtualHost *:38667>
    ServerName   $(hostname --fqdn)
    DocumentRoot "/var/log/weblogs"
    DirectoryIndex index.html  index.jsp
    <Location />
        Options +Indexes
        Order deny,allow
        Allow from all
    </Location>

    Alias /logs  "/var/log/weblogs"
    <Directory "/var/log/weblogs">
        Options +FollowSymLinks +Indexes +MultiViews
        AllowOverride None
        Order allow,deny
        Allow from 192.168.0.0/255.255.0.0
        Allow from 4.20.98.115
        Allow from 10.129.0.0/255.255.0.0
        Allow from 10.50.0.0/255.255.0.0
        Allow from 10.130.0.0/255.255.0.0
        Allow from 10.170.0.0/255.255.0.0
        Allow from 69.63.0.0/255.255.0.0
        Allow from 172.16.0.0/255.255.0.0

        Require all granted
        Satisfy Any
    </Directory>
</VirtualHost>

EOF

chown $AEM_USER:$AEM_GROUP $CQ_CONF

# create logrotate script
cat > $CQ_LOGROTATE << EOF
# log rotation for cq app

$AEM_LOG/*.log {
    su $AEM_USER $AEM_GROUP
    daily
    rotate 5
    missingok

#    # clean up log files from previously mal-formed logrotate config 
#    # this section can be removed once it's been run everywhere
#    prerotate
#        find -L $AEM_LOG -name "*.log-*"       -type f -exec rm -f {} \;
#        find -L $AEM_LOG -name "*.log.gz-*"    -type f -exec rm -f {} \;
#        find -L $AEM_LOG -name "*.log.?-"      -type f -exec rm -f {} \;
#        find -L $AEM_LOG -name "*.log.2019-[0-9][0-9]-[0-9][0-9]-*"      -type f -exec rm -f {} \;
#        find -L $AEM_LOG -name "aem-gc.log.?.current-*"      -type f -exec rm -f {} \;
#        find -L $AEM_LOG -type f -mtime +5 -exec rm -f {} \;
#    endscript
}

EOF

# symlink log directory
rm -rf $AEM_LOG
ln -s $AEM_DIR/crx-quickstart/logs $AEM_LOG

# start the app
/etc/init.d/$AEM_INIT start

# start AppDynamics
service wsgc-machineagent start

exit 0
