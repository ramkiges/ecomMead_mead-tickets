#!/bin/sh
# setup sftp for pradm and singleuse
REPO=https://repos.wsgc.com/svn/devops/application/pradm
GROUP=webadmin
DATA=/apps/sftpdata
#SHELL="\$(which nologin)"
SHELL="\$(which bash)"

BailOut() {
  [[ -n $1 ]] && echo "$*"
  exit 1
}

ENV=$1
[ -z "$ENV" ] && BailOut "Need env"

SCRIPT=/tmp/setup-sftp-server-$ENV

USER=$(svn cat $REPO/$ENV/config/app/trunk/pom.xml 2>/dev/null | grep pradm.sftpDownloadUser | awk -F '[<>]' '{ print $3 }')
PASS=$(svn cat $REPO/$ENV/config/app/trunk/pom.xml 2>/dev/null | grep pradm.sftpDownloadPwd  | awk -F '[<>]' '{ print $3 }')
KEY=$(basename $(svn cat $REPO/$ENV/config/app/trunk/pom.xml 2>/dev/null | grep pradm.sftpKeyPath  | awk -F '[<>]' '{ print $3 }'))

[[ -z $USER ]] && BailOut "No pradm.sftpDownloadUser for $ENV"
[[ -z $PASS ]] && BailOut "No pradm.sftpDownloadPwd for $ENV"
[[ -z $KEY ]] && BailOut "No pradm.sftpKeyPath for $ENV"

svn cat $REPO/$ENV/config/app/trunk/src/main/resources/sys/ssh/$KEY > /tmp/$KEY
svn cat $REPO/$ENV/config/app/trunk/src/main/resources/sys/ssh/$KEY.pub > /tmp/$KEY.pub

svn cat $REPO/$ENV/config/app/trunk/src/main/resources/sys/ssh/id_rsa.tomcat > /tmp/id_rsa.tomcat
svn cat $REPO/$ENV/config/app/trunk/src/main/resources/sys/ssh/id_rsa.tomcat.pub > /tmp/id_rsa.tomcat.pub
chmod 600 /tmp/$KEY*

PUB_SFTP=$(cat /tmp/$KEY.pub | awk '{ print $2 }')
PUB_TOMCAT=$(cat /tmp/id_rsa.tomcat.pub | awk '{ print $2 }')

cat > $SCRIPT << EOF
#!/bin/sh
PUB_SFTP="$PUB_SFTP"
PUB_TOMCAT="$PUB_TOMCAT"
SHELL=$SHELL

grep -q "$USER" /etc/passwd || useradd -g $GROUP -d $DATA -f -1 -K PASS_MAX_DAYS=-1 -s \$SHELL $USER 
echo "$PASS" | sudo passwd "$USER" --stdin
usermod -f 0 -c "Promo Admin SFTP user" $USER
chsh -s \$SHELL $USER
rm -f $DATA/.bash_logout $DATA/.bash_profile $DATA/.bashrc $DATA/.kshrc $DATA/.sh_history
mkdir -p $DATA/.ssh
chmod 700 $DATA/.ssh
cp /tmp/$KEY* $DATA/.ssh
cp /tmp/id_rsa.tomcat* $DATA/.ssh

if [ ! -d /home/tomcat/.ssh ]
then
  mkdir -p /home/tomcat/.ssh
  chmod 700 /home/tomcat/.ssh  
fi

# add key to authorized_keys
grep -q $USER /home/tomcat/.ssh/authorized_keys 2>/dev/null || echo "ssh-rsa \$PUB_SFTP $USER" >> /home/tomcat/.ssh/authorized_keys
grep -q tomcat /home/tomcat/.ssh/authorized_keys 2>/dev/null || echo "ssh-rsa \$PUB_TOMCAT tomcat" >> /home/tomcat/.ssh/authorized_keys
grep -q $USER $DATA/.ssh/authorized_keys 2>/dev/null || echo "ssh-rsa \$PUB_SFTP $USER" >> $DATA/.ssh/authorized_keys
grep -q tomcat $DATA/.ssh/authorized_keys 2>/dev/null || echo "ssh-rsa \$PUB_TOMCAT tomcat" >> $DATA/.ssh/authorized_keys

cp /tmp/$KEY* /home/tomcat/.ssh
cp /tmp/id_rsa.tomcat* /home/tomcat/.ssh
chmod 600 /home/tomcat/.ssh/id_rsa*
chown -R tomcat:webadmin /home/tomcat/.ssh

chown -R $USER:$GROUP $DATA/.ssh
chmod 600 $DATA/.ssh/$KEY*
chmod 644 $DATA/.ssh/authorized_keys 

authconfig --enablesssd --enablesssdauth --enablemkhomedir --update

ls -l $DATA/.ssh
ls -l /home/tomcat/.ssh

EOF

chmod 755 $SCRIPT 
chmod 700 /tmp/$KEY*
scp -q $SCRIPT /tmp/$KEY /tmp/$KEY.pub /tmp/id_rsa.tomcat* singleuse-$ENV-rk1v:/tmp
scp -q $SCRIPT /tmp/$KEY /tmp/$KEY.pub /tmp/id_rsa.tomcat* pradm-$ENV-rk1v:/tmp

for host in singleuse-$ENV-rk1v pradm-$ENV-rk1v 
do
  echo "> $host"    
  ssh -q -tt $host "sudo $SCRIPT"
done

