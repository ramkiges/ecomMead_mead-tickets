
svn up

#propset -f pom.xml -p frontend.tableOwner -v DTCITG_APP_ADMIN
#propset -f pom.xml -p frontend.datasource.ecomDB.username -v dtcitg_app_admin
#propset -f pom.xml -p frontend.datasource.ecomDB.password -v I4pp4dmin
#propset -f pom.xml -p frontend.datasource.session.username -v dtcitg_app_admin
#propset -f pom.xml -p frontend.datasource.session.password -v I4pp4dmin

propset -f pom.xml -p frontend.tableOwner -v DTCITG_APP_OWNER
propset -f pom.xml -p frontend.datasource.ecomDB.username -v dtcitg_app_owner
propset -f pom.xml -p frontend.datasource.ecomDB.password -v I#4pp0wn3r
propset -f pom.xml -p frontend.datasource.session.username -v dtcitg_app_owner
propset -f pom.xml -p frontend.datasource.session.password -v I#4pp0wn3r

svn diff

svn commit -m "[DEVOPS] update dtcitg creds"

