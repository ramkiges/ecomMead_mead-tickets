#!/bin/sh
PATH=/apps/mead-tools:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:~/bin

MSG=
for x in 1 2 3
do
  for dc in sac rk
  do
    #host="cas${dc}-vicn00$x"
    host="cassandra-qa1-${dc}${x}"
    host $host >/dev/null 2>&1 || continue
    echo "host: $host"
    #xss $host

    status=$(ssh -q -tt $host "sudo service wsgc-dse status" | grep -i "running")
    echo "$host: $status"
    MSG="$host: $status
$MSG"
    #[[ $status =~ not ]] && ssh -q -tt $host "sudo service wsgc-dse restart"
  done
done

exit

#jenkins-jnlp build -s deploy-oauth-qa 

for jira in $*
do
  jira-label $jira "RestartCassandra"
  jira-label $jira "RestartOauth"
  jira-close -t $jira -c " (i) $(basename $0) QA Cassandra and Oauth restarted 
$MSG"
done

