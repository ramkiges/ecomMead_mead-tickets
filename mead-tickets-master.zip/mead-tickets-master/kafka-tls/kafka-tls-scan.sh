#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/sbin:/usr/bin:/usr/sbin:~/bin
# generate a list of hosts with filebeat installed, and whether it's packaged or not

BailOut() {
  [[ -n $1 ]] && echo "$*"
  exit 255
}

#LABEL=$(basename $0 | sed -es/\.sh//g)
LABEL=kafka-tls
TMP=/tmp/$LABEL-$LOGNAME
DATE=$(date +'%Y-%m-%d %H:%M')

SSL_PRD_AB="kafash-vccn010.wsgc.com:31095 kafash-vccn011.wsgc.com:31096 kafash-vccn012.wsgc.com:31097 kafash-vccn013.wsgc.com:31098 kafash-vccn014.wsgc.com:31099"
SSL_PRD_RK="kafrck-vccn010.wsgc.com:31095 kafrck-vccn011.wsgc.com:31096 kafrck-vccn012.wsgc.com:31097 kafrck-vccn013.wsgc.com:31098 kafrck-vccn014.wsgc.com:31099"
SSL_NONPRD="kafrck-vicn017.wsgc.com:31095 kafrck-vicn018.wsgc.com:31096 kafrck-vicn019.wsgc.com:31097 kafrck-vicn020.wsgc.com:31098 kafrck-vicn021.wsgc.com:31099"

WRK=$TMP/src/main/resources/wsgc
RUNDECK_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git
TICKET_REPO=git@github.wsgc.com:eCommerce-Mead/mead-tickets.git
BAD_HOSTS="aerodbprdab2"
TIMEOUT="--connect-timeout 30 --max-time 60"

which sshpass >/dev/null 2>&1 || BailOut "Need sshpass"
which yq >/dev/null 2>&1 || BailOut "Need yq"

#SSH_KEY=/home/rundeck/.ssh/id_rsa
#SSH_USER=imageuser
SSH_KEY=$HOME/.ssh/id_rsa
SSH_USER=a_${LOGNAME}
SSH_OPTS=" -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY"
export SSHPASS=$(cat ~/.pass)

NCCR=$TMP/mead-tickets/kafka-tls/$LABEL-nccr.csv
INVALID=$TMP/mead-tickets/kafka-tls/invalid-hosts.csv
rm -f $INVALID

rm -rf $TMP
mkdir -p $TMP

git clone -q --depth 1 $RUNDECK_REPO $TMP/rundeck
git clone -q --depth 1 $TICKET_REPO $TMP/mead-tickets

#echo "Host,<target>:<port>=<reachable>" > $NCCR

[[ -n $1 ]] && HOST_LIST=$* 
[[ -z $1 ]] && HOST_LIST=$(grep -ihr "hostname=" $TMP/rundeck | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | tr -d '"' | awk -F\. '{ print $1 }'  | egrep -iv "$BAD_HOSTS" | sort -u)

for host in $HOST_LIST
do
    APP=
    ORG=ecom

    pkg=
    loc=
    cfg=
    kafka_fb=
    kafka_pp=
    platprop=

    host $host >/dev/null 2>&1 || { echo $host >> $INVALID; continue; }
    sshpass -e ssh-copy-id -i $SSH_KEY -f $SSH_USER@$host > /dev/null 2>&1 &
    ssh -o BatchMode=yes $SSH_OPTS $SSH_USER@$host "hostname" >/dev/null 2>&1
    [[ $? -ne 0 ]] && { echo "ssh failed for $host"; continue; }

    tags=$(grep -hr $host $TMP/rundeck \
      | awk -F 'tags=' '{ print $2 }' \
      | awk -F\" '{ print $2 }' \
      | tr '[:upper:]' '[:lower:]' \
      | sed -es/-new//g \
      | sed -es/','/' '/g -es/apmagents//g -es/guardrail_node//g \
      | sed -es/'\bgr\b'//g -es/'\bmg\b'//g -es/'\bpb\b'//g -es/'\bpk\b'//g -es/'\bpt\b'//g -es/'\brj\b'//g -es/'\bwe\b'//g -es/'\bws\b'//g \
      | xargs -n1 | sort -u | tr '\n' ' ' \
      | tr -d '\r' \
      | tail -1\
    )
    echo "$tags" | egrep -iq "jenkins" && continue
    echo "$tags" | egrep -iq "aes|aem|cma|ws-recipe|wcm|edam|wcm|ecmpub|ecmauth" && ORG=scns
    
    OUT_PRD=$TMP/mead-tickets/kafka-tls/$LABEL-$ORG-prd.csv
    OUT_NONPRD=$TMP/mead-tickets/kafka-tls/$LABEL-$ORG-nonprd.csv

    # grab the filebeat packlage version
    #pkg=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "rpm -qa | grep -i filebeat " | sed -es/\.x86_64//g -es/filebeat-//g| tr -d '\r')
    #[[ -z $pkg ]] && continue

    # file the filebeat config files
    cfg=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "ls -l /etc/filebeat/*.yml 2>/dev/null | egrep -iv 'reference|fields' | awk '{ print \$NF }'" | tr '\n' ' ' | tr -d '\r')
    if [[ -n $cfg ]]
    then
      # grab the filebeat kafka hosts
      kafka_fb=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "cat $cfg 2>/dev/null </dev/null " | yq eval '."output.kafka"."hosts"' 2>/dev/null | sed -es/\.wsgc\.com//g | tr -cd "'[:alnum:]-: ")

      # grab the src of the filebeat config package
      src=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "rpm -q --whatprovides $cfg" | head -1 | grep -i wsgc | awk -F_ '{ print $1 }' | sed -r 's/-[0-9]+$//g' | tr -d '\r')
    fi

    # find the log4j2.xml config files
    #log4j=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "find /apps -maxdepth 5 -name log4j2.xml 2>/dev/null | egrep -iv 'appdynamics|jmeter'" | tail -1 | tr '\n' ' ' | tr -d '\r')

    # find the platform.properties files
    platprop=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "find /apps -maxdepth 5 -name platform.properties 2>/dev/null | egrep -iv 'jmeter|appdynamics'" | tail -1 | tr -d '\r' | tr '\n' ' ' )
    if [[ -n $platprop ]]
    then
      kafka_pp=$(sshpass -e ssh $SSH_OPTS $SSH_USER@$host "grep -i 'kafkaServers' $platprop 2>/dev/null | awk -F= '{ print \$2 }' | tr ',' ' ' " | tr '\n' ' ' | tr -cd "'[:alnum:]-: ")
      kafka_pp=$(sed -es/\.wsgc\.com//g -es/kafkaServers//g -es/wsgccom//g -es/telemetry//g <<< $kafka_pp) 
    fi

    OUT=$OUT_NONPRD
    [[ $tags =~ production || $tags =~ prod || $tags =~ prdab || $tags =~ prdrk || $tags =~ prdsac || $tags =~ preprd ]] && OUT=$OUT_PRD 
    echo "$tags" | egrep -iqw "prd" && OUT=$OUT_PRD
    echo "$tags" | egrep -iq "ecmprd" && OUT=$OUT_PRD
    echo "$tags" | egrep -iq "nonprd" && OUT=$OUT_NONPRD
    echo "$host" | egrep -iq "vpcn" && OUT=$OUT_PRD

    echo "$tags" | egrep -iq "frontend" && APP="DP"
    echo "$tags" | egrep -iq "WCM" && APP="WCM"
    echo "$tags" | egrep -iq "ECM" && APP="ECM"
    echo "$tags" | egrep -iq "aem" && APP="AEM"
    echo "$tags" | egrep -iq "cma" && APP="CMA"
    echo "$tags" | egrep -iq "profile" && APP="Profile"
    echo "$tags" | egrep -iq "loyalty" && APP="Loyalty"
    echo "$tags" | egrep -iq "oss" && APP="OSS"
    echo "$tags" | egrep -iq "homefront" && APP="HomeFront"
    echo "$tags" | egrep -iq "registry" && APP="Registry"
    echo "$tags" | egrep -iq "scc" && APP="SCC"
    echo "$tags" | egrep -iq "cassandra" && APP="Cassandra"
    echo "$tags" | egrep -iq "cre" && APP="CRE"
    echo "$tags" | egrep -iq "pradm" && APP="PromoAdmin"
    echo "$tags" | egrep -iq "pricing" && APP="Pricing"
    echo "$tags" | egrep -iq "singleuse" && APP="Singleuse"
    echo "$tags" | egrep -iq "oauth" && APP="Oauth"
    echo "$tags" | egrep -iq "favorites" && APP="Favorites"
    echo "$tags" | egrep -iq "invent-adjustment" && APP="Invent-Adjustment"
    echo "$tags" | egrep -iq "cpcr" && APP="CPCR"
    echo "$tags" | egrep -iq "portal" && APP="ESRE Portal"
    echo "$tags" | egrep -iq "buildsystem" && APP="buildsystem"
    echo "$tags" | egrep -iq "bgb" && APP="BGB"
    echo "$tags" | egrep -iq "xcadm" && APP="AdminTool"
    echo "$tags" | egrep -iq "vertex" && APP="Vertex"
    echo "$tags" | egrep -iq "df" && APP="DataFeeds"
    echo "$tags" | egrep -iq "corp" && APP="Corp"
    echo "$tags" | egrep -iq "contentprocessor" && APP="ContentProcessor"
    echo "$tags" | egrep -iq "verify-config" && APP="DevOps"
    echo "$tags" | egrep -iq "aero" && APP="Aerospike"
    echo "$tags" | egrep -iq "ecmagent" && APP="ECM Agent"
    echo "$tags" | egrep -iq "c3" && APP="C3"

    cfg=$(echo "$cfg" |  sed -es%/etc/filebeat/%%g)
    echo "$DATE,$host,$APP,$tags,$src,$cfg,$kafka_fb,$kafka_pp" | tee -a $OUT

#    [[ $tags =~ prdab || $tags =~ prdrk || $tags =~ prdsac ]] && LIST="$SSL_PRD_AB $SSL_PRD_RK" || LIST=$SSL_NONPRD
#    LINE="$host,"
#    for x in $SSL_PRD_AB $SSL_PRD_RK
#    do
#      r=$(ssh -q $host "curl $TIMEOUT -fsqk $x >/dev/null 2>&1;echo $?" | tr -d '\r')
#      LINE="$LINE $x=$r"
#    done
#    echo "$LINE" | tee -a $NCCR
done

{ set +x; } 2>/dev/null

cd $TMP/mead-tickets/kafka-tls

git pull

cd $TMP/mead-tickets/kafka-tls
for out in $LABEL-ecom-prd $LABEL-ecom-nonprd $LABEL-scns-prd $LABEL-scns-nonprd 
do
  echo "Date, Host,App,RunDeck Tags,WSI Package,Config File,Filebeat Kafka Hosts,Log4j Kafka Hosts" > $out.csv.new
done

for out in $LABEL-ecom-prd $LABEL-ecom-nonprd $LABEL-scns-prd $LABEL-scns-nonprd
do
  hosts=$(awk -F, '{ print $2 }' $out.csv | sort -u | egrep -iv "Host")
  for h in $hosts
  do
      grep -w "$h" $out.csv | tail -1 >> $out.csv.new
  done

  mv $out.csv.new $out.csv      
  sed -es/' ,'/','/g -i $out.csv
  git add $out.csv
done

git commit -q -m "Update data $(date +'%Y%m%d%H%M')"
git push --force

exit 0
