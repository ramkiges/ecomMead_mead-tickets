#!/bin/sh

BRAND=rj
ENVIRO=$1
[[ -z $ENVIRO ]] && exit 1

cd $(cat ~/.wsi_settings)/application/frontend-2.1/qa/config/app/trunk/$BRAND || exit 1
svn up

POM=$ENVIRO/pom.xml
PXY=pb
ORG=$BRAND

if ! [[ -e $POM ]]
then
  echo "Can't find $POM"
  exit 1
fi

HOST=$(gethost $BRAND $ENVIRO | awk -F\. '{ print $1 }')

#propset -f $POM -p frontend.war.name -v  wsgc-$BRAND-fe-ecom-Shasta-rejuventation-onboarding

propset -f $POM -p frontend.crossdomainList -v '*.${frontend.domain},*.${frontend.brand}imgs.com,*.wsgc.com'

#propset -f $POM -p frontend.appBase       -v http://$HOST.wsgc.com/
#propset -f $POM -p frontend.secureAppBase -v https://$HOST.wsgc.com/

propset -f $POM -p frontend.scriptSubPath -v ${ORG}imgs/qark/images/uat1/
propset -f $POM -p frontend.scriptSubPath -v ${ORG}imgs/qark/images/uat1/

propset -f $POM -p frontend.contentImageBase        -v http://img-qa-rk1v.wsgc.com/${PXY}imgs/qark/images/dp/
propset -f $POM -p frontend.secureContentImageBase  -v https://img-qa-rk1v.wsgc.com/${PXY}imgs/qark/images/dp/

propset -f $POM -p frontend.docImageBase        -v http://img-qa-rk1v.wsgc.com/${ORG}imgs/qark/images/uat1/
propset -f $POM -p frontend.secureDocImageBase  -v https://img-qa-rk1v.wsgc.com/${ORG}imgs/qark/images/uat1/

#propset -f $POM -p frontend.catImageBase       -v https://img-qa-rk1v.wsgc.com/${ORG}imgs/qa/images/dp/
#propset -f $POM -p frontend.secureCatImageBase -v https://img-qa-rk1v.wsgc.com/${ORG}imgs/qa/images/dp/
#propset -f $POM -p frontend.catImageBase       -v http://imgproc-rgs2-sac1v.wsgc.com/pubimagesrgs2/${PXY}/images/
#propset -f $POM -p frontend.secureCatImageBase -v https://imgproc-rgs2-sac1v.wsgc.com/pubimagesrgs2/${PXY}/images/

propset -f $POM -p frontend.remoteProxyImageBase -v http://img-qa-rk1v.wsgc.com/${ORG}imgs/qark/images/uat1/
propset -f $POM -p frontend.secureRemoteProxyImageBase -v https://img-qa-rk1v.wsgc.com/${ORG}imgs/qark/images/uat1/

svn commit -m "[DEVOPS] temporary hacks until the site is legit" $POM

set -x 

jenkins-jnlp build -s wsgc-devops-frontend21-qa-single-env -p BRAND=$BRAND -p ENVIRONMENT=$ENVIRO

#jenkins-jnlp build -s checkenv Brand=$BRAND -p Environment=$ENVIRO -p Options=Deploy-War -p Options=Rebuild-Config -p Options=Clear-Logs 
#-p Options=Deploy-Content 

#cd ~/wsgc/mead-tickets
#scp -q $BRAND-server-hack.sh $HOST:/tmp
#ssh -q -tt $HOST "sh /tmp/server-hack.sh $ENVIRO" 

