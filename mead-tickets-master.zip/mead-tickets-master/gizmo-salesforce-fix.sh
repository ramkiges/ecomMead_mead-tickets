#!/bin/sh
# this spoon-feeds the salesforce app onto the server  the packaging is broken
PATH=$PATH:/apps/java/bin

REPO=https://artifactory.wsgc.com/artifactory/wsgc-releases/com/wsgc/gizmotron/salesforce-gizmos/ 

TMP=/tmp/gizmo
rm -rf $TMP
mkdir -p $TMP
cd $TMP || exit 1

LATEST=$(curl -fsqk $REPO | grep "<a href=\"[0-9].*/" | awk -F '[<>]' '{ print $3 }' | sort -V | tail -1 | sed -es%/%%g)

set -x
curl -fsqk -O ${REPO}${LATEST}/salesforce-gizmos-${LATEST}.war 

ls -l /apps/tomcat-gizmotron-salesforce/apps/salesforce/salesforce-gizmos.war *.war

sudo cp salesforce-gizmos-$LATEST.war /apps/tomcat-gizmotron-salesforce/apps/salesforce/salesforce-gizmos.war

jar xf /apps/tomcat-gizmotron-salesforce/apps/salesforce/salesforce-gizmos.war WEB-INF/classes/salesforce/query

sudo cp $(find $TMP -name query -print)/* /apps/tomcat-gizmotron-salesforce/salesforce/query

sudo chown tomcat:webadmin /apps/tomcat-gizmotron-salesforce/salesforce/query/*

sudo chmod 775 /apps/tomcat-gizmotron-salesforce/salesforce/query 

sudo mkdir -p /apps/tomcat-gizmotron-salesforce/webapps/ROOT
cd /apps/tomcat-gizmotron-salesforce/webapps/ROOT
sudo /apps/java/bin/jar xf $TMP/salesforce-gizmos-${LATEST}.war
sudo chown -R tomcat:webadmin /apps/tomcat-gizmotron-salesforce

sudo service wsgc-tomcat-gizmotron-salesforce restart 

