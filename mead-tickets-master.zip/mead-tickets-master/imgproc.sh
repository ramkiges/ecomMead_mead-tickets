#!/bin/sh

exit 0
IMGPROC_HOSTS="imgproc-prd-rk1v imgproc-uat1-rk1v imgproc-qa2-rk1v imgproc-qa-sac1v"
WCM_HOSTS="pb-wcm-uat1-rk1v pb-wcm-qa2-rk1v pb-wcm-qa1-sac1v pb-wcm-uat1-rk1v"

for imgproc in $IMGPROC_HOSTS 
do
    IMGPROC_OS=$(ssh -q $imgproc "cat /etc/centos-release | sed 's/[^0-9\.]//g' | awk -F\. '{ print \$1 }'")
    IMGPROC_WGET=$(ssh -q $imgproc "wget --version | head -1 | sed 's/[^0-9\.]//g'")
    for wcm in $WCM_HOSTS
    do
        WCM_OS=$(ssh -q $wcm "cat /etc/centos-release | sed 's/[^0-9\.]//g' | awk -F\. '{ print \$1 }'")
        WCM_WGET=$(ssh -q $wcm "wget --version | head -1 | sed 's/[^0-9\.]//g'")
        CMD="wget --no-check-certificate --auth-no-challenge --no-verbose -O- http://contentprocessor:contentprocessor@$wcm:38600/content/dam/pb/2011/0519/010/swa2-CamillaPillow_Neutral.tif >/dev/null 2>&1"
        #echo "$CMD"
        RES=$(ssh -q $imgproc "$CMD;echo \$?")
        [ "$RES" = 0 ] && RES="Yes" || RES="No"

        echo "$imgproc/$IMGPROC_OS/$IMGPROC_WGET        $wcm/$WCM_OS/$WCM_WGET      $RES"
        sleep 2
    done        

done


