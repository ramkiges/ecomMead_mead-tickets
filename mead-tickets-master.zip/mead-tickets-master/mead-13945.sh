#!/bin/sh

jenkins-jnlp build -s wsgc-devops-wcm-rgs-config-any -p ENVIRONMENT=rgs -p BRANCH=wcm-aes -p WCM_VERSION=5.14.3

sleep 1500

jenkins-jnlp build -s deploy-wcm-nonprd-any -p Brand=pb -p Environment=rgs -p Artifact=wcm-aes

