#!/bin/sh
#TODO: update this to use ~/.credentials.d
# https://accounts.appdynamics.com/downloads

BailOut() {
  [[ -n $1 ]] && echo "$*"
  exit 255
}

[[ -z $1 ]] && BailOut "Usage: $(basename $0) <file1> [file2] ..."

# .npmrepo is where the creds would be kept
NPM_CRED=$HOME/.npmrepo

# validate NPM repo creds
[ -z "$NPM_CRED" ] && BailOut "NPM cred file variable undefined (NPM_CRED)"
[ -f "$NPM_CRED" ] || BailOut "Can't find NPM cred file ($NPM_CRED)"

source $NPM_CRED
[ -z "$NPM_USER" ] && BailOut "Can't parse NPM user from $NPM_CRED"
[ -z "$NPM_PASS" ] && BailOut "Can't parse NPM pass from $NPM_CRED"
LOGIN="$NPM_USER:$NPM_PASS"

for FILE in $*
do
  echo $FILE | grep -q "^appdynamics-nodejs-standalone" || { echo "Error: '$FILE' isn't a valid appdynamics nodejs package"; continue; }
  VERSION=$(echo $FILE | awk -F- '{ print $7 }' | awk -F\. '{ print $1 "." $2 "." $3 }' )
  OS=$(basename $FILE | awk -F- '{ print $4 }')
  ARCH=$(basename $FILE | awk -F- '{ print $5 }')
  NODE=$(basename $FILE | awk -F- '{ print $6 }')
  EXT=$(basename $FILE | awk -F\. '{ print $NF }')
  TARGET="appdynamics-nodejs-standalone-$OS-$ARCH-$NODE.$EXT"

  #curl -u $LOGIN --upload-file $FILE https://npmrepo-dev.wsgc.com/repository/wsgc-raw-local/nodejs/${VERSION}/appdynamics-standalone.tgz --insecure
  #curl -u $LOGIN --upload-file $FILE https://npmrepo.wsgc.com/repository/wsgc-raw-local/nodejs/${VERSION}/appdynamics-standalone.tgz --insecure

  echo "Uploading $FILE -> $VERSION/$TARGET"
  curl -u $LOGIN --upload-file $FILE https://npmrepo-dev.wsgc.com/repository/wsgc-raw-local/appdynamics/${VERSION}/$TARGET --insecure
  curl -u $LOGIN --upload-file $FILE https://npmrepo.wsgc.com/repository/wsgc-raw-local/appdynamics/${VERSION}/$TARGET --insecure
  echo
done

