#!/bin/sh

HOST=cassandra-qa1-rk2.wsgc.com

for b in MG PB PK PT WE WS
do
  Q="select authorities from wsi_user_identity.oauth_client_details where client_id = 'ecom_${b}/QA';"
  A=$(echo "$Q" | cqlsh --cqlversion=3.4.4 $HOST | grep "ROLE" | sed -es/' '//g)
  echo "$A" | grep -q "ROLE_OMS_SHIPMENTS_TRACKING_DETAILS" && continue
  echo
  U="UPDATE wsi_user_identity.oauth_client_details SET authorities = '$A,ROLE_OMS_SHIPMENTS_TRACKING_DETAILS' where client_id = 'ecom_${b}/QA';"
  echo "$b: $U"
  echo "$U" | cqlsh --cqlversion=3.4.4 $HOST 
  echo
done

