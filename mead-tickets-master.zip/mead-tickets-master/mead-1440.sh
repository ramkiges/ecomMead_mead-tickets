#!/bin/sh

export PATH=$PATH:~/py3/bin/wsi_settings
cd /wsgc/svn/devops/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties
svn up

ALL_ENV="int1,int2,qa1,qa2,qa3,qa4,qa5,qa6,qa7,qa8,qa9,qa10,qa11,qa12,qa13,qa14,qa15,qa16,uat1,uat2,uat3,rgs1"
ALL_BRAND="pb,pk,pt,ws,we,mg"
IR="int1,int2,rgs1"
QAUA="qa1,qa2,qa3,qa4,qa5,qa6,qa7,qa8,qa9,qa10,qa11,qa12,qa13,qa14,qa15,qa16,uat1,uat2,uat3"

#int1,int2,qa1,qa2,qa3,qa4,qa5,qa6,qa7,qa8,qa9,qa10,qa11,qa12,qa13,qa14,qa15,qa16,rgs1,uat1,uat2,uat3,rgs1

wsi_settings --env $ALL_ENV --brand mg 			update APPCONF.IS_GIFT_DEFAULT --type b true 	--force
wsi_settings --env $ALL_ENV --brand pb,pk,pt,ws,we 	update APPCONF.IS_GIFT_DEFAULT --type b false 	--force

wsi_settings --env $ALL_ENV --brand $ALL_BRAND update ENDECAMOBILE.PAGESPECS 24 --type i --force

wsi_settings --env $IR --brand pb,pk,pt,ws,we update CONTPERS.EMAIL_CAPTURE_RESTRICTED_URLS checkout,account,shoppingcart,registry,intl-order-tracking,order-shipment-tracking,catalog-request --type a --force

#svn status
#svn commit -m "[MEAD-1440] updated app settings"


