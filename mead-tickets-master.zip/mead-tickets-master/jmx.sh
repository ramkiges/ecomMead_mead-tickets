#!/bin/sh

ENVS="qa1 qa2 qa3 qa4 qa5 qa6 qa7 qa8 qa9 \
qa10 qa11 qa12 qa13 qa14 qa15 qa16 qa17 qa18 qa19 \
qa20 qa21 qa22 qa23 qa24 qa25 qa26 qa27 qa28 qa29 \
qa30 qa31 qa32 qa33 qa34 qa35 qa36 qa37 qa38 qa39 \
qa40 qa41 qa42 qa43 qa44 qa45 qa46 qa47 qa48 qa49 \
qa50 qa51 qa52 qa53 qa54 qa55 \
uat1 uat2 uat3 uat4 uat5 uat6 rgs int2"

for e in $ENVS
do
  for b in mg pb pb pt we ws
  do
    host=$(get-host $b $e)
    echo "host: $host"
    sed -es/@HOST@/$host/g -i jmx.groovy
    groovy jmx.groovy >/dev/null 2>&1 &
    echo
  done
done
