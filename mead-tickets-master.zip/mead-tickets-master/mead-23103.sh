#!/bin/sh
TICKET=$(basename $0 | tr "A-Z" "a-z" | sed -es/\.sh//g)
OUT=$TICKET.out
ENV=qa27
BRANCH=rimo-wrk-190926
FORCE=false

for x in 1 2 3 4 5
do 
  for b in mg pb pk pt we ws
  do
    #jenkins-jnlp build -s deploy-qa27-$b-CONTENT_rimo-wrk-190926 -p FORCEBUILD=false -p TICKET=$TICKET #>> $OUT 2>&1
    jenkins-jnlp build -s deploy-$ENV-$b-CONTENT_${BRANCH} -p FORCEBUILD=$FORCE -p TICKET=$TICKET #>> $OUT 2>&1
    ret=$?
    echo "$b,$ENV,$BRANCH,$FORCE,$ret" >> $OUT
  done
done

git add $OUT 
git commit $OUT -m "[$TICKET] update build job stats"
git push

