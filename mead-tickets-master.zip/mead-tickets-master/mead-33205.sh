#!/bin/sh

BRAND=ws
ENVIRO=qa32
TICKET=$(basename $0 | tr '[:lower:]' '[:upper:]' | sed -es/\.SH//g)

jenkins-jnlp build -s wsgc-devops-frontend21-common </dev/null >/dev/null 2>&1

jenkins-jnlp build -s wsgc-devops-frontend21-qa-app-config </dev/null  >/dev/null 2>&1

jenkins-jnlp build -s wsgc-devops-frontend21-qa-$BRAND-app-config </dev/null  >/dev/null 2>&1

jenkins-jnlp build -s checkenv -p Brand=$BRAND -p Environment=$ENVIRO -p Options=Clear-Logs -p Options=Deploy-War -p Options=Rebuild-Config -p Ticket="$TICKET" </dev/null >/dev/null 2>&1

