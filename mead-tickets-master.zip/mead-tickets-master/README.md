# mead
This is a collection of short little scripts for handing MEAD tickets; the name of the script is usually the ticket number
