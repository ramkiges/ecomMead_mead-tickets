#!/bin/sh

#cd $(cat $HOME/.wsi_settings)/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site/webqa2/qa_app_owner
#svn up || exit 1

for b in mg pb pk pt we ws
do
    echo "$b"       

    OUT=/tmp/ecmprvuat-$b.txt
    rm -f $OUT
      
    cd $(cat $HOME/.wsi_settings)/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site/webqa2/qa_app_owner/$b/override
    svn up || exit 1

    sed -i -es/'.ecmprvint.'/'.emcprvuat.'/g override.properties
done
