#!/bin/sh

TICKET=$(basename $0 | tr "a-z" "A-Z" | sed -es/\.SH//g)
TYPES="n r a b s i m p t l h"

for brand in mg pb pk pt we ws
do
  echo
  echo "$brand"
  cd $(cat $HOME/.wsi_settings)/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site/webqa2/ws_app_owner/$brand/override
  svn up -q

  for type in $TYPES
  do
    sed -es/"\.qa\.$type="/"\.qa1\.$type="/g -i override.properties
  done
  svn diff override.properties | egrep "^\+|^\-"
  svn commit override.properties -m "[$TICKET] change qa -> qa1"

done

