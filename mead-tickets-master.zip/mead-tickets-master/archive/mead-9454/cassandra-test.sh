#!/bin/sh
USER=cassandra
PASS=cassandra
GEN_SUPPORT=yes

HOSTS="casrck-vicn001"
#HOSTS="casrck-vdcn001"
#HOSTS="cassandra-dev1-rk1"

TEST="deleteme-$$"
CQLVERSION_LIST="3.4.0 3.4.4"

for CASSANDRA in $HOSTS
do
    echo "---------------------------------------------------------------------------------"
    echo "node: $CASSANDRA"
    echo
    ssh -q $CASSANDRA "hostname"
    if [ $? -ne 0 ]
    then
        echo "Can't ssh to $CASSANDRA"
        continue
    fi

    #cd /wsgc/mead/mead-9454
    cd /wsgc/mead-tickets/archive/mead-9454
    if [ -n "$GEN_SUPPORT" ]
    then
        scp -q cassandra-support.sh $CASSANDRA:/tmp
        ssh -q $CASSANDRA "sh /tmp/cassandra-support.sh"
        scp -q $CASSANDRA:/etc/dse/cassandra/cassandra.yaml ~/Downloads/$CASSANDRA-cassandra.yaml
        scp -q $CASSANDRA:/etc/dse/cassandra/cassandra-env.sh ~/Downloads/$CASSANDRA-cassandra-env.sh
        scp -q $CASSANDRA:/var/log/weblogs/cassandra/system.log ~/Downloads/$CASSANDRA-system.log
        scp -q $CASSANDRA:/var/log/weblogs/cassandra/debug.log ~/Downloads/$CASSANDRA-debug.log
        scp -q $CASSANDRA:/var/log/weblogs/cassandra/output.log ~/Downloads/$CASSANDRA-output.log
        scp -q $CASSANDRA:/tmp/cassandra-support.txt ~/Downloads/$CASSANDRA-support.txt
        cd ~/Downloads
        rm -f $CASSANDRA.zip
        zip -q $CASSANDRA.zip $CASSANDRA-debug.log $CASSANDRA-debug.log $CASSANDRA-system.log $CASSANDRA-output.log $CASSANDRA-support.txt $CASSANDRA-cassandra.yaml $CASSANDRA-cassandra-env.sh
        rm -f ~/Downloads/$CASSANDRA-debug.log ~/Downloads/$CASSANDRA-system.log ~/Downloads/$CASSANDRA-output.log ~/Downloads/$CASSANDRA-support.txt
        #cd /wsgc/mead/mead-9454
        cd /wsgc/mead-tickets/archive/mead-9454
    fi

    REPAIR=/tmp/cassandra-repair.sh
    STATUS=/tmp/cassandra-status.sh
    for CQLVERSION in $CQLVERSION_LIST
    do
        # throwaway query to test the cqlversion we need to use
        echo "describe keyspaces;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA >/dev/null 2>&1 || continue

        echo
        echo "Server: $CASSANDRA ($CQLVERSION)"

        ssh -q $CASSANDRA "rpm -qa | grep -i wsgc-.*datastax"

        #echo "describe keyspaces;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA 
        KEYSPACES=$(echo "describe keyspaces;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA )

        #echo "INSERT INTO system_auth.roles (role,can_login,is_superuser,member_of,salted_hash) VALUES ('$TEST',false,false,null,'');" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA

        # validation queries
        #echo "cqlsh --cqlversion=$CQLVERSION $CASSANDRA"
        echo "SELECT * FROM system_auth.roles ;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA
        #echo "SELECT * FROM wsi_loyalty.loyalty_cards ;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA
        #echo "SELECT * FROM wsi_legacy_profile.address ;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA

        echo "show version;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA
        echo "select release_version from system.local;" | cqlsh --cqlversion=$CQLVERSION $CASSANDRA

        continue

        #nodetool -h $CASSANDRA -u $USER -pw $PASS status

        cat > $STATUS << EOF
#!/bin/sh    
KEYSPACES="$(echo $KEYSPACES)"

for keyspace in \$KEYSPACES
do
    echo "KeySpace: \$keyspace"
    nodetool -u $USER -pw $PASS repair --full \$keyspace
    nodetool -u $USER -pw $PASS status \$keyspace
    echo
done

EOF

        cat > $REPAIR << EOF
#!/bin/sh    
KEYSPACES="$(echo $KEYSPACES)"

for keyspace in \$KEYSPACES
do
    echo "KeySpace: \$keyspace"
    #nodetool -u $USER -pw $PASS repair --full \$keyspace
    nodetool -u $USER -pw $PASS snapshot \$keyspace
    nodetool -u $USER -pw $PASS status \$keyspace
    echo
done

#sudo /etc/init.d/wsgc-datastax-agent stop
#sudo /etc/init.d/wsgc-dse stop
#sudo tar cf /database/database-snapshot.tar \$(find /database -maxdepth 1 -type d | egrep -vi "lost\+found")

EOF

        chmod 755 $REPAIR $STATUS $EXPORT
        scp -q $REPAIR $STATUS $EXPORT cassandra-* $CASSANDRA:/tmp &
    done
done

