#!/bin/sh

if [ "$1" != "go" ]
then
    echo "Need to run this with the 'go' option"
    exit 1
fi

OLD_PKG=$(rpm -qa | grep -o "wsgc-.*datastax.*config")
echo "Config pkg: $OLD_PKG"
NEW_PKG=$(/usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* list available 2>/dev/null | grep -i $OLD_PKG | sed -es/"\.noarch"//g)
if [ -z "$NEW_PKG" ]  
then
    echo "Can't find an updated package for $OLD_PKG"
    exit 1
fi

OLD_PKG=$(rpm -qa | grep -o "wsgc-.*datastax.*config")
echo "Config pkg: $OLD_PKG"
NEW_PKG=$(/usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* list available 2>/dev/null | grep -i $OLD_PKG | sed -es/"\.noarch"//g)
if [ -z "$NEW_PKG" ]  
then
    echo "Can't find an updated package for $OLD_PKG"
    exit 1
fi

set -x
nodetool status
nodetool flush
# this is already done in the prep script
#nodetool repair --full 
nodetool upgradesstables
nodetool drain
set +x

sudo yum -y install yum-utils -d0
sudo yum-complete-transaction --cleanup-only -d0
sudo /usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* clean all -d0
sudo /usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* clean metadata -d0

sudo /etc/init.d/wsgc-datastax-agent stop
sudo /etc/init.d/wsgc-dse stop
sudo su - cassandra -c "/usr/bin/dse cassandra-stop"

set -x
sudo /usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* --enablerepo=wsi-\* update $NEW_PKG
set +x

sudo /etc/init.d/wsgc-datastax-agent start
sudo /etc/init.d/wsgc-dse start
sleep 120

rpm -qa | egrep -i "^wsgc|^dse" | sort

# these are probably not needed
#sudo ln -s /etc/dse/tomcat/conf/catalina.properties /usr/share/dse/tomcat/conf/catalina.properties
#sudo ln -s /etc/dse/tomcat/conf/context.xml /usr/share/dse/tomcat/conf/context.xml

#nodetool upgradesstables

