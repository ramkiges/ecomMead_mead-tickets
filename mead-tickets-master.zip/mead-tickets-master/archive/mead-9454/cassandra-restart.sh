#!/bin/sh

sudo chkconfig wsgc-dse on
sudo systemctl daemon-reload

sudo /etc/init.d/wsgc-datastax-agent start
sudo /etc/init.d/wsgc-dse start
sudo service wsgc-machineagent restart

sudo systemctl status wsgc-dse.service

