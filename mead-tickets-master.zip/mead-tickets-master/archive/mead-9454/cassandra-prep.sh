#!/bin/sh
DATE=$(date +'%Y-%m-%d-%H%M')
#ACTION=echo
ACTION=eval
USER=cassandra
PASS=cassandra

[ "$(uname)" = "Linux" ] || exit 1

# capture a list of packages
PACKAGES=/database/packages.txt
cat > /tmp/pkglist.sh << EOF
touch $PACKAGES
echo >> $PACKAGES
date >> $PACKAGES
rpm -qa | egrep -i 'wsgc|dse' | sort >> $PACKAGES
echo >> $PACKAGES
chmod 775 /database
chmod 666 $PACKAGES
EOF
sudo sh /tmp/pkglist.sh

FLAGS=$(grep -w "EXTRA_FLAGS=" /etc/init.d/wsgc-dse | awk -F= '{ print $2 }' | sed -es/\"//g | egrep -iv "EXTRA_FLAGS")
if [ -z "$FLAGS" ] 
then
    echo "You need to set  EXTRA_FLAGS=\"-Dcassandra.force_3_0_protocol_version=true\" in /etc/init.d/wsgc-dse "
    exit 
fi

OLD_PKG=$(rpm -qa | grep -o "wsgc-.*datastax.*config")
echo "Config pkg: $OLD_PKG"
NEW_PKG=$(/usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* list available 2>/dev/null | grep -i $OLD_PKG | sed -es/"\.noarch"//g)
[ -z "$NEW_PKG" ] && echo "Can't find an updated package for $OLD_PKG"

# prep for update
#$ACTION nodetool -u $USER -pw $PASS repair --full
#ACTION nodetool -u $USER -pw $PASS upgradesstables
#$ACTION nodetool -u $USER -pw $PASS clearsnapshot
$ACTION nodetool -u $USER -pw $PASS status

#$ACTION sudo /etc/init.d/wsgc-datastax-agent stop
#$ACTION sudo /etc/init.d/wsgc-dse stop
#$ACTION sudo su - cassandra -c "/usr/bin/dse cassandra-stop"
#$ACTION sleep 90

$ACTION sudo tar cf /database/cassandra-$DATE.tar \
    /apps/cassandra \
    /apps/datastax-agent \
    /apps/dse \
    /etc/rc.d/init.d/wsgc-dse \
    /etc/default/dse \
    /etc/init.d/wsgc-datastax-agent \
    /etc/init.d/wsgc-dse \
    /etc/rc.d/init.d/dse \
    /etc/dse \
    /usr/bin/dse \
    /usr/share/dse  \
    --exclude='*.tar'

#$ACTION sudo /etc/init.d/wsgc-datastax-agent start
#$ACTION sudo /etc/init.d/wsgc-dse start
#$ACTION sudo su - cassandra -c "/usr/bin/dse cassandra -Dcassandra.force_3_0_protocol_version=true"
#$ACTION sleep 90

#$ACTION nodetool -u $USER -pw $PASS status

