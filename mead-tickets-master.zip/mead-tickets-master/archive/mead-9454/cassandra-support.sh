#!/bin/sh
# this script gathers up various stuff datastax support might want
export PATH=/bin:/usr/bin:/sbin:/sbin:/usr/sbin:/usr/local/bin:/apps/java/bin:/apps/python3/bin
USER=casssandra
PASS=cassandra

JAVA_HOME=/apps/java

OUT=/tmp/cassandra-support.txt
rm -f $OUT

cat > $OUT 2>&1 << EOF
$(date)
$(hostname)
$(java -version)

$(rpm -qa | grep -i 'dse')

set -x
$(nodetool -u $USER -pw $PASS status)

$(dsetool --username $USER --password $PASS status)

$(nodetool -u $USER -pw $PASS  info)

$(nodetool -u $USER -pw $PASS netstats)

$(nodetool -u $USER -pw $PASS tpstats)

$(nodetool -u $USER -pw $PASS compactionstats)

$(ps -ef | grep -i cassandra | egrep -iv "grep|$$|cassandra-status|cassandra-repair" ) 

#$(ls -lR /database/data)

EOF

