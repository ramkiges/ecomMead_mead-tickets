#!/bin/sh

HEADER="# Host, IP, JDK Link, Installed JDKs"
DATE=$(date +'%Y-%m-%d')

NODES_PRD=jdk-inventory-prd.nodes
NODES_NONPRD=jdk-inventory-nonprd.nodes

OUT_PRD="jdk-inventory-prd.csv"
OUT_NONPRD="jdk-inventory-nonprd.csv"
touch $OUT_PRD $OUT_NONPRD 

CERT_NONPRD="certs-nonprd.csv"
rm -f $CERT_NONPRD
echo "Host, CertDate" > $CERT_NONPRD

pingTest(){
    ping -c 2 $1  >/dev/null 2>&1 
}

for node in $(cat $NODES_NONPRD)
do
    pingTest $node || continue
    IP=$(host $node |grep -i address | awk '{ print $NF}')

    SSH="sshpass -e ssh -q $SSHOPTS ${SSHUSER}@$node"
    grep -iq "$node" $OUT_NONPRD || wsikey $node >/dev/null 2>&1 
    #JDK_DATE=$($SSH "ls -ld --time-style=full /apps/java 2>/dev/null | awk '{ print \$6 }'")
    JDK_LINK=$($SSH "ls -ld /apps/java 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' ')
    [ -z "$JDK_LINK" ] && JDK_LINK=$($SSH "ls -ld /apps/jdk8 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' ')
    [ -z "$JDK_LINK" ] && JDK_LINK=$($SSH "ls -ld /apps/jdk8-latest 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' ')
    #[ -z "$JDK_LINK" ] && { sleep 90; JDK_LINK=$($SSH "ls -ld /apps/java 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' '); }
    [ -z "$JDK_LINK" ] && JDK_LINK="(no link)"
    #echo "$JDK_LINK" | egrep -iq "jdk1.8.0_45" && echo xss $node
    cat $OUT_NONPRD | grep -iv "$node" > $OUT_NONPRD.new && mv $OUT_NONPRD.new $OUT_NONPRD
    echo "$node,$IP,$JDK_LINK" 
    echo "$node,$IP,$JDK_LINK" >> $OUT_NONPRD
    #scp -q jdk-update $node:/tmp >/dev/null 2>&1 &

    #CERT_DATE=$(openssl s_client -connect $node.wsgc.com:443 -servername $node.wsgc.com -showcerts </dev/null 2>&1| openssl x509 -noout -dates 2>&1 | grep -i notafter | awk -F= '{ print $2 }')
    CERT_DATE=$(openssl s_client -connect $node.wsgc.com:443 -servername $node.wsgc.com -showcerts </dev/null 2>&1| openssl x509 -noout -enddate 2>&1 | grep -i notafter | awk -F= '{ print $2 }')
    #[ -n "$CERT_DATE" ] && echo "cert: $node,$CERT_DATE" 
    [ -n "$CERT_DATE" ] && echo "$node,$CERT_DATE" >> $CERT_NONPRD
done

git pull
sort -u $OUT_NONPRD >> $OUT_NONPRD.new && mv $OUT_NONPRD.new $OUT_NONPRD
git add $OUT_NONPRD $CERT_NONPRD >/dev/null 2>&1
git commit -m "Updated results" $OUT_NONPRD $CERT_NONPRD >/dev/null 2>&1
git push >/dev/null 2>&1

for node in $(cat $NODES_PRD)
do
    pingTest $node || continue
    IP=$(host $node |grep -i address | awk '{ print $NF}')

    SSH="sshpass -e ssh -q $SSHOPTS ${SSHUSER}@$node"
    grep -iq "$node" $OUT_PRD || wsikey $node >/dev/null 2>&1 
    #JDK_DATE=$($SSH "ls -ld --time-style=full /apps/java 2>/dev/null | awk '{ print \$6 }'")
    JDK_LINK=$($SSH "ls -ld /apps/java 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' ')
    [ -z "$JDK_LINK" ] && JDK_LINK=$($SSH "ls -ld /apps/jdk8 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' ')
    #[ -z "$JDK_LINK" ] && { sleep 90; JDK_LINK=$($SSH "ls -ld /apps/java 2>/dev/null | awk '{ print \$NF }' | sed -es%/apps/%%g -es%/%%g " |  tr '\012\015' ' '); }
    [ -z "$JDK_LINK" ] && JDK_LINK="(no link)"
    cat $OUT_PRD | grep -iv "$node" > $OUT_PRD.new && mv $OUT_PRD.new $OUT_PRD
    #echo "$node,$IP,$JDK_LINK" 
    echo "$node,$IP,$JDK_LINK" >> $OUT_PRD
done

git pull
sort -u $OUT_PRD >> $OUT_PRD.new && mv $OUT_PRD.new $OUT_PRD
git add $OUT_PRD >/dev/null 2>&1
git commit -m "Updated results" $OUT_PRD >/dev/null 2>&1
git push >/dev/null 2>&1


