#!/bin/sh

DEVOPS=https://repos.wsgc.com/svn/devops/
#DEVOPS=https://repos.wsgc.com/svn/devops/application/favorites
#DEVOPS=https://repos.wsgc.com/svn/devops/application/mdm

JDK_SEARCH="<.*jdklink|<.*java.*version>|<.*jdkversion>"
EXCEPT="tags|deprecated|sandbox|scripts|svn-access|toolchain|tools|devscripts|dashboard|branches|wsgc-tomcat-parent"
JDK_OUT="$HOME/mead/mead-9053/jdk-properties.csv"
REPO_LIST="$HOME/mead/mead-9053/repolist.txt"
touch $JDK_OUT $REPO_LIST

GENREPO=

BailOut() {
    [ -n "$1" ] && echo "$*"
    exit 1
}

git pull

# create a list of all the repos we need to search through
if [ -n "$GENREPO" ]
then
    for file in $(svn list --recursive $DEVOPS | egrep -i "pom.xml|readme" | egrep -vi "$EXCEPT")
    do
        if echo "$file" | grep -iq "readme"
        then
            REPO=$(svn cat "$DEVOPS/${file}" | grep -i https)
        else
            REPO=$DEVOPS${file}
        fi
        echo "> $file   $REPO"
        echo "$REPO" >> $REPO_LIST
    done
    egrep "repos.wsgc|github.wsgc|pom.xml" $REPO_LIST | sort -u > $REPO_LIST.new;mv $REPO_LIST.new $REPO_LIST 
fi

for file in $(cat $REPO_LIST | egrep -i "https|github" | egrep -iv "wsgc-tomcat-parent")
#for file in $(sort -u $REPO_LIST | egrep -i "https|github" | egrep -iv "wsgc-tomcat-parent")
do
    JDK_PROP=
    JDK_VER=

    if echo "$file" | grep -iq "repos.wsgc"
    then
        echo "$file" | grep -iq trunk || continue
        REPO=$(dirname $file)
        JDK_PROP=$(svn cat $file 2>/dev/null | \
            egrep -i "$JDK_SEARCH" | \
            egrep -iv -- "property|message|require|location|cmdline|home|--" | \
            awk -F '[<>]' '{ print $2 }' )

        JDK_VER=$(svn cat $file 2>/dev/null | \
            egrep -i "<$JDK_PROP>" | \
            egrep -vi '\$\{' | \
            awk -F '[<>]' '{ print $3 }')

        [ -n "$JDK_VER" ] && JDK_PROP="$JDK_PROP" 

        JDK_REQ=$(svn cat $file 2>/dev/null | \
            egrep -i "<require.*jdk" | \
            awk -F '[<>]' '{ print $3 }' | \
            sort -u | \
            tr '\012' ' ' )
    else
        REPO=$file
        GIT=$(echo "$REPO" | sed -es%https://github.wsgc.com/%git@github.wsgc.com:%g)
        rm -rf tmp; mkdir -p tmp
        git clone $GIT tmp >/dev/null 2>&1 || { echo "Can't clone $GIT"; continue; }
        for pom in $(find tmp -name pom.xml 2>/dev/null)
        do
            JDK_PROP=$(egrep -i "$JDK_SEARCH" $pom | \
                egrep -iv -- "property|message|require|location|cmdline|--" | \
                awk -F '[<>]' '{ print $2 }' )

            [ -n "$JDK_PROP" ] && JDK_VER=$(egrep -i "<$JDK_PROP>" $pom | \
                egrep -vi '\$\{' | \
                awk -F '[<>]' '{ print $3 }' )

            JDK_REQ=$(egrep -i "<require.*jdk" $pom | \
                awk -F '[<>]' '{ print $3 }' | \
                tr '\012' ' ' )
        done
    fi

    [ -z "$JDK_PROP" -a -z "$JDK_REQ" ] && continue
    echo "* $REPO: $JDK_PROP $JDK_REQ"
                 
    cat $JDK_OUT | egrep -iv "$REPO" | sort -u > $JDK_OUT.new 
    mv $JDK_OUT.new $JDK_OUT            
    #echo "$REPO,$JDK_PROP,$JDK_REQ" >> $JDK_OUT
    echo "$REPO,$JDK_PROP,$JDK_VER,$JDK_REQ" >> $JDK_OUT
done

cd $HOME/mead/mead-9053 || BailOut "Where are we?"
git pull >/dev/null 2>&1

echo "# Repo, Property, Version, Packages" > $JDK_OUT.new
egrep "repos.wsgc|github.wsgc" $JDK_OUT | sort -u >> $JDK_OUT.new ;mv $JDK_OUT.new $JDK_OUT 

git add $(basename $JDK_OUT) $(basename $REPO_LIST)
git commit $(basename $JDK_OUT) -m "updated jdk property list"
git commit $(basename $REPO_LIST) -m "updated repository list"
git push

