#!/bin/sh

BRAND=ws
SRC=qa9
DST=qa6

PROPS=" frontend.jms.providerUrl frontend.jms.username frontend.jms.password frontend.jms.subscriberClientId frontend.jmsWismo.providerUrl frontend.jmsWismo.username frontend.jmsWismo.password frontend.jmsWismo.usernameCov2 frontend.jmsWismo.passwordCov2 frontend.jmsOrder.providerUrl frontend.jmsOrder.username frontend.jmsOrder.password frontend.jmsOrderPricing.providerUrl frontend.jmsOrderPricing.username frontend.jmsOrderPricing.password frontend.jmsOrderReservation.providerUrl frontend.jmsOrderReservation.username frontend.jmsOrderReservation.password frontend.jmsOrderCreate.providerUrl frontend.jmsOrderCreate.username frontend.jmsOrderCreate.password frontend.loyaltyJms.url frontend.loyaltyJms.queueName frontend.loyaltyJms.username frontend.loyaltyJms.password "


SRC_POM=$(echo $(geturls $BRAND $SRC | grep pom.xml))
DST_POM=$(echo $(geturls $BRAND $DST | grep pom.xml))

cd $(dirname $SRC_POM) && svn up
cd $(dirname $DST_POM) && svn up

for prop in $PROPS
do
	key=$(grep "$prop" $SRC_POM  | awk -F '[<>]' '{ print $2 }')
	[ -z "$key" ] && continue

	v_src=$(propget -f $SRC_POM -p $key)
	v_dst=$(propget -f $DST_POM -p $key)
	
	[ "$v_src" = "$v_dst" ] && continue
	echo "Prop: $key $SRC: $v_src $DST: $v_dst "
	
	propset -f $DST_POM -p "$key" -v "$v_src"
done

svn commit $DST_POM -m "[MEAD-5047] clone values from $SRC"
