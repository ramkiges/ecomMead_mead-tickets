
#RPM=wsgc-devops-rerun-module-wcm-2.0-20180628.140822-20.rpm
RPM=wsgc-devops-rerun-module-wcm-2.0-20180628.144423-22.rpm

rpm -qa | grep -i wsgc | grep -i rerun

curl -k https://snapshotrepo.wsgc.com/artifactory/snapshotrepo/com/wsgc/devops/rerun-module/wsgc-devops-rerun-module-wcm/2.0-SNAPSHOT/$RPM -o /tmp/wsgc-devops-rerun-module-wcm.rpm

rpm -Uvh --oldpackage /tmp/wsgc-devops-rerun-module-wcm.rpm

rpm -qa | grep -i wsgc 

echo

rpm -qa | grep -i wsgc | grep -i rerun

