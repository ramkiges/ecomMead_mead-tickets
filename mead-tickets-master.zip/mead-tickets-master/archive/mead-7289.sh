#!/bin/sh

ENV=qa13
MEAD=MEAD-7289

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up

ACTION=eval
for BRAND in mg pb pk pt we ws
do

	POM=$(getpom $BRAND $ENV)
	if [ -z "$POM" ]
	then
		echo "Can't find pom for $BRAND $ENV"
		exit 1
	fi

#jms
#jmsWismo
#jmsOrder
#jmsOrderPricing
#jmsOrderReservation
#jmsOrderCreate

	for prop in jmsOrder jmsOrderCreate jmsOrderReservation jmsOrderPricing jmsWismo
	do
		propset -f $POM -p frontend.$prop.providerUrl -v tcp://tibinttstmp3p.wsgc.com:20011
		propset -f $POM -p frontend.$prop.username -v apptibco
		propset -f $POM -p frontend.$prop.password -v n3tw0rk
	
	done
	
	svn diff $POM
	$ACTION svn commit $POM -m "[$MEAD] update OMSD parameters"
done
