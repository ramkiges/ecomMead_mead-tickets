
ENV=uat3
MEAD=7283

for BRAND in mg pb pk pt we ws
do

POM=$(getpom $BRAND $ENV)

for prop in jmsOrder jmsOrderCreate jmsOrderReservation
do

	propset -f $POM -p frontend.$prop.providerUrl -v tcp://tibintpprdrk1p.wsgc.com:10006
	propset -f $POM -p frontend.$prop.username -v appecomqa1
	propset -f $POM -p frontend.$prop.password -v fastqa1

	svn diff $POM

	svn commit $POM -m "[MEAD-$MEAD] update OMSD parameters"
done

done
