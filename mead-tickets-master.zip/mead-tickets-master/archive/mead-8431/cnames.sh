
grep pbteen.com dns-qa.txt |
while read line
do
    #echo "line: $line"          
    old_cname=$(echo "$line" | awk '{ print $1 }')
    new_cname=$(echo "$old_cname" | sed -es/pbteen/potterybarnteen/g)
    origin=$(echo "$line" | awk '{ print $4 }')
    #ip=$(echo "$line" | awk '{ print $9 }')
    #[ -z "$ip" ] && ip=$(host origin-$old_cname |grep -i address | awk '{ print $NF }')

    #echo "$new_cname    -> $origin"
    host $new_cname
done
