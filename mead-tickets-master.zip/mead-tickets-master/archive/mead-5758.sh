
ENV=int1

for BRAND in we
do

POM=$(getpom $BRAND $ENV)

propset -f $POM -p frontend.jmsOrderPricing.providerUrl -v tcp://tibinttstsac7p.wsgc.com:20001
propset -f $POM -p frontend.jmsOrderPricing.username -v apptibco
propset -f $POM -p frontend.jmsOrderPricing.password -v n3tw0rk

propset -f $POM -p frontend.jmsOrderReservation.providerUrl -v tcp://tibinttstmp1p.wsgc.com:20001
propset -f $POM -p frontend.jmsOrderReservation.username -v usrdev
propset -f $POM -p frontend.jmsOrderReservation.password -v w1nt3r

propset -f $POM -p frontend.jmsOrderCreate.providerUrl -v tcp://tibinttstmp3p.wsgc.com:20011
propset -f $POM -p frontend.jmsOrderCreate.username -v apptibco
propset -f $POM -p frontend.jmsOrderCreate.password -v n3tw0rk

svn commit $POM -m "[MEAD-5758] update OMSD parameters"
done
