# copy app settings from one env to another
BRANDS="we"
ENV="qa14"
NEW_DB=webqa1/r1_app_owner
OLD_DB=webqa2/dtcmou_app_owner

MEAD=$(basename $0 | tr "A-Z" "a-z" | sed -e s/[a-z]//g | sed -e s/-//g | sed -e s/\.$//g)
TMP=/wsgc/mead/mead-$MEAD.save

cd /wsgc/svn/devops/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site
#svn cleanup
svn up
[ "$ENV" = "rgs1" ] && ENV="regression"
[ "$ENV" = "rgs2" ] && ENV="regression2"

for b in $BRANDS
do
	[ -z "$OLD_DB" ] && OLD_DB=$(geturls $b $ENV|grep -i override | awk -F/ '{ print $(NF-4) "/" $(NF-3) }')
	if [ -z "$OLD_DB" ]
	then
		echo "Can't figure out old DB"
		exit 1
	fi
	OLD_DIR=$OLD_DB/$b/override
	NEW_DIR=$NEW_DB/$b/override

	PROPS=/tmp/properties-$ENV-$b
	mkdir -p $TMP

	[ -f $TMP/override.properties.$b ] || cp $NEW_DIR/override.properties $TMP/override.properties.$b

	# seed the new file with the existing properties from the new schema
	cat $NEW_DIR/override.properties > $PROPS
	echo >> $PROPS

	# add the properties for $ENV to the newly seeded file
	cat $OLD_DIR/override.properties | egrep -i "\.$ENV\." | egrep -vi "^#" | sort -u >> $PROPS

	#ls -l $PROPS
	#diff $NEW_DIR/override.properties $PROPS

	#cp $PROPS $NEW_DIR/override.properties
	#ls -l $NEW_DIR/override.properties
done

#MSG="copy $BRANDS $ENV appsettings from $OLD_DB to $NEW_DB"
#svn commit -m "[MEAD-$MEAD] $MSG"

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up

for BRAND in $BRANDS
do
	POM=$(geturls $BRAND $ENV | grep -i pom.xml)
	[ -z "$POM" ] && BailOut "can't get pom dir for $BRAND $ENV"

	cd $(dirname $POM)
	svn up
	echo "pom: $POM"

	propset -f pom.xml -p frontend.tableOwner -v "R1_APP_OWNER"

	propset -f pom.xml -p frontend.datasource.ecomDB.url -v "jdbc:oracle:thin:@webqark1p:3800:webqa1"
	propset -f pom.xml -p frontend.datasource.ecomDB.username -v "R1_APP_USER"
	propset -f pom.xml -p frontend.datasource.ecomDB.password -v "ENC:nLK5d/+owdbS5mU3xSvA+cYSYHECAWBeUBGNamne62U="
	propset -f pom.xml -p frontend.datasource.session.url -v "jdbc:oracle:thin:@webqark1p:3800:webqa1"
	propset -f pom.xml -p frontend.datasource.session.username -v "R1_APP_USER"
	propset -f pom.xml -p frontend.datasource.session.password -v "ENC:swLoxuxoxJOvFj0zlH2xQI87bt1GXl3RrL5eNWxjlSw="

	propset -f pom.xml -p frontend.epsKeyStoreLocation -v "/apps/tomcat/conf/frontend_keystore.jks"
	propset -f pom.xml -p frontend.epsKeyStoreType -v "JKS"
	propset -f pom.xml -p frontend.epsKeyStorePassword -v "password"
	propset -f pom.xml -p frontend.epsKeyStoreAlias -v "wsirootca"

	MSG="Convert $BRANDS $ENV to fugazi"
	svn commit -m "[MEAD-$MEAD] $MSG"

	#echo wsi_settings --env $ENV --brand $BRAND update EC.HOST --type s 10.170.224.16
	#echo wsi_settings --env $ENV --brand $BRAND update EC.PORT --type s 49181
	#echo wsi_settings --env $ENV --brand $BRAND update PAYMENT.TOKENIZATION_EPS_URLS --type a https://ecinvent-qa-rk1v.wsgc.com:49182/gizmotron/service/payment-service/v1
done

