
ENV=uat3

for BRAND in we
do

POM=$(getpom $BRAND $ENV)

propset -f $POM -p frontend.jmsOrderPricing.providerUrl -v tcp://tibinttstsac7p.wsgc.com:20001
propset -f $POM -p frontend.jmsOrderPricing.username -v apptibco
propset -f $POM -p frontend.jmsOrderPricing.password -v n3tw0rk

propset -f $POM -p frontend.jmsOrderReservation.providerUrl -v tcp://tibinttstmp1p.wsgc.com:20001
propset -f $POM -p frontend.jmsOrderReservation.username -v usrdev
propset -f $POM -p frontend.jmsOrderReservation.password -v w1nt3r

propset -f $POM -p frontend.jmsOrderCreate.providerUrl -v tcp://tibinttstmp3p.wsgc.com:20011
propset -f $POM -p frontend.jmsOrderCreate.username -v apptibco
propset -f $POM -p frontend.jmsOrderCreate.password -v n3tw0rk

svn commit $POM -m "[MEAD-5767] update OMSD parameters"
done

#      <frontend.jmsOrderPricing.providerUrl>tcp://tibinttstsac7p.wsgc.com:20001</frontend.jmsOrderPricing.providerUrl>
#      <frontend.jmsOrderPricing.username>apptibco</frontend.jmsOrderPricing.username>
#      <frontend.jmsOrderPricing.password>n3tw0rk</frontend.jmsOrderPricing.password>
#      <frontend.jmsOrderReservation.providerUrl>tcp://tibinttstmp1p.wsgc.com:20001</frontend.jmsOrderReservation.providerUrl>
#      <frontend.jmsOrderReservation.username>usrdev</frontend.jmsOrderReservation.username>
#      <frontend.jmsOrderReservation.password>w1nt3r</frontend.jmsOrderReservation.password>
#      <frontend.jmsOrderCreate.providerUrl>tcp://tibinttstmp3p.wsgc.com:20011</frontend.jmsOrderCreate.providerUrl>
#      <frontend.jmsOrderCreate.username>apptibco</frontend.jmsOrderCreate.username>
#      <frontend.jmsOrderCreate.password>n3tw0rk</frontend.jmsOrderCreate.password>

