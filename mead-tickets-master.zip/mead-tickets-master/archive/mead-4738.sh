#!/bin/sh

for brand in mg pb pk pt we ws
#for brand in mg 
do
echo "$brand:"
	cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk/$brand/qa16
	svn up >/dev/null 2>&1
	cat /wsgc/mead/mead-4738.txt | egrep -v "^#" |
	while read line
	do
		#echo "line: $line"
		k=$(echo "$line" | awk '{ print $1 }')
		v=$(echo "$line" | awk '{ print $2 }')

		k=$(echo "$k" | sed -e s/jmsorder/jmsOrder./gi)
		k=$(echo "$k" | sed -e s/JmsWISMO/JmsWismo./gi)
		k=$(echo "$k" | sed -e s/JMSSubscriberClientId/jms.subscriberClientId/gi)
		k=$(echo "$k" | sed -e s/jmsorder.Pricing/jmsOrderPricing./gi)
		k=$(echo "$k" | sed -e s/jmsorder.create/jmsOrderCreate./gi)
		k=$(echo "$k" | sed -e s/JmsInventoryReservation/jmsOrderReservation./gi)
		k=$(echo "$k" | sed -e s/username/username/gi)
		k=$(echo "$k" | sed -e s/password/password/gi)
		k=$(echo "$k" | sed -e s/providerurl/providerUrl/gi)

		p=$(grep -i "$k" pom.xml | awk -F '[<>]' '{ print $3 }')
		if [ -n "$p" ]
		then
			if [ "$p" != "$v" ]
			then
				echo "Old:    <frontend.$k>$p</frontend.$k>"
				echo "New:    <frontend.$k>$v</frontend.$k>"
			fi
		else
			echo "      <frontend.$k>$v</frontend.$k>"
		fi	
	done
	echo
done

