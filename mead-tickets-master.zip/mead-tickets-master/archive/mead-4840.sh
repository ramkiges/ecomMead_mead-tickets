
TOKEN="j3uczk37e4cfa6q3nc5q2nss"

#set -x
curl -v -s -k \
-H 'X-Client-Context:Mmh0cGd2bnp2OW1jbm0yMmZtNmJ5dGdwOjllZnZlWUU0anY=' \
-H 'Content-type:application/x-www-form-urlencoded' \
-H 'Authorization: Basic cGJxYXVzZXI6aG0zRnVybg==' \
-d 'username=jgunchy@wsgc.com&password=Password1&scope=profile registry&grant_Type=password' \
'https://integration2.williams-sonoma.com/profiles/v1/login.json' 

#set -x
#curl -v -s -k \
#-H "Authorization: Bearer $TOKEN" \
#'https://services.williams-sonoma.com/int2/profiles/v1/self/index.json'
#set +x
#
#echo

#curl -s -k -H "Authorization: Bearer $TOKEN" 'https://services.williams-sonoma.com/int2/profiles/v1/self/index.json'
