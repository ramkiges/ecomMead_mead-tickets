#!/bin/sh

ENV=uat5
MEAD=DEVOPS

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up

for BRAND in mg 
do

	POM=$(getpom $BRAND $ENV)
	if [ -z "$POM" ]
	then
		echo "Can't find pom for $BRAND $ENV"
		exit 1
	fi

#jms
#jmsWismo
#jmsOrder
#jmsOrderPricing
#jmsOrderReservation
#jmsOrderCreate


	for prop in jmsOrder jmsOrderCreate jmsOrderReservation
	do

		propset -f $POM -p frontend.$prop.providerUrl -v tcp://tibintpprdrk1p.wsgc.com:10006
		propset -f $POM -p frontend.$prop.username -v appecomqa1
		propset -f $POM -p frontend.$prop.password -v fastqa1
	
	done
	
	svn diff $POM
	svn commit $POM -m "[$MEAD] update OMSD parameters"
done
