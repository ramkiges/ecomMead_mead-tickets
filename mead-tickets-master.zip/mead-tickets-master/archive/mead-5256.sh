
NV="http://invadj-qa1-rk1v/odis-display-season-artifacts/"

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up
for ENV in qa18 int2
do
	for BRAND in pb ws we pk
	do
		POM=$(getpom $BRAND $ENV)	
		echo "pom: $POM"
		key=$(grep -i RemoteContentArchiveUrlBases $POM | awk -F '[<>]' '{ print $2 }')
		if [ -z "$key" ]
		then
			echo "$BRAND/$ENV does not contain RemoteContentArchiveUrlBases"
			#v="http://imgqark1v:49190/tmpl/, http://mg-intdev17-rk1:38667/tmpl/,http://imgqark1v:49190/tmpl2/"
			continue
		else
			v=$(propget -f $POM -p $key)
		fi

		echo "$v" | grep -qi "$NV" || v="$v,$NV"

		echo propset -f $POM -p $key -v "$v"
echo "v: $v"
	done
done
