BRAND=mg

cd /wsgc/svn/devops/application/wcm
svn up

cd /wsgc/svn/devops/application/wcm/qa/config/cm/trunk/src/main
#apm-on "[MEAD-5106] turn on APM - qa"
apm-off "[MEAD-5106] turn off APM - qa"

cd /wsgc/svn/devops/application/wcm/qa/config/cm/trunk/$BRAND/qa1/src/main
#apm-on "[MEAD-5106] turn on APM - qa/$BRAND"
apm-off "[MEAD-5106] turn off APM - qa/$BRAND"

jenkins build -f wsgc-devops-wcm-qa-config-cm
#jenkins build deploy-wcm-qa-$BRAND

