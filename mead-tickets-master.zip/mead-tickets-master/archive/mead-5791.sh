#!/bin/sh

BRAND=pb
ENV=qa18

POM=$(getpom $BRAND $ENV)

cd $(dirname $POM)


propset -f $POM -p frontend.jms.providerUrl -v tcp://tibintpprdrk1p:10006
#propset -f $POM -p frontend.jms.subscriberClientId -v pb-int2-rk1v
#propset -f $POM -p frontend.jmsWismo.username -v appservices
propset -f $POM -p frontend.jmsOrder.providerUrl -v tcp://tibintpprdrk1p.wsgc.com:10006

