
ROOT=/wsgc/svn/devops/application/frontend-2.1/common/config/trunk/src/main/resources/tomcat/conf/Catalina/localhost/ROOT.xml

ENV=qa18
for BRAND in pk we ws
do
	NEW_ROOT=/wsgc/tomcat-$BRAND-qa18-ROOT.xml
	DST_POM=$(getpom $BRAND $ENV)

	for param in $(grep -i "environment name=" $NEW_ROOT | awk -F "name=" '{ print $2 }' | awk -F "value=" '{ print $1 }' | sed -es/\"//g | egrep -iv "=")
	do
		#echo "> $param"
		key=$(grep -iw $param $ROOT | awk -F "value=" '{ print $2 }' | sed -e s/\"//g | awk '{print $1 }' | sed -es/[{}]//g -es/\\$//g)
		#echo "key: $key"

set -x
		new_prop=$(grep -iw "$param" $NEW_ROOT | awk -F "value=" '{ print $2 }' | awk -F "type=" '{ print $1 }' | sed -es/\"//g)
set +x
		old_prop=$(propget -f $DST_POM -p $key)

		[ -z "$old_prop" ] && continue
		if [ "$old_prop" != "$new_prop" ]
		then
			echo "$param $key old:[$old_prop] new:[$new_prop]"	
		fi
	done

	
break
done
