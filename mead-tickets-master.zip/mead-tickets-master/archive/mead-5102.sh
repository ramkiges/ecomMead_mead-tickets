#!/bin/sh

ENV=qa17

for BRAND in mg pb pk pt we ws
do
POM=$(echo $(geturls $BRAND $ENV | grep pom.xml))
cd $(dirname $POM) && svn up

#key=$(grep "$prop" $ENV_POM  | awk -F '[<>]' '{ print $2 }')

#propset -f $POM -p "frontend.epsKeyStoreLocation" -v "/apps/tomcat/conf/frontend_epsKeystore.jks"
#propset -f $POM -p "frontend.epsKeyStoreLocation" -v "/apps/tomcat/conf/frontend_epsKeystore_qa.jks"
#propset -f $POM -p "frontend.epsKeyStorePassword" -v "password"
#propset -f $POM -p "frontend.epsKeyStoreAlias" -v "eps_tibinttstmp7p"

#svn commit $POM -m "[MEAD-5102] un-fugazi "
update $BRAND $ENV deploy >/dev/null 2>&1 &

done
