
#NV="http://invadj-qa1-rk1v/odis-display-season-artifacts/"

NV="http://imgqark1v:49190/tmpl/,http://imgqark1v:49190/tmpl2/,http://invadj-qa1-rk1v/odis-display-season-artifacts/"

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up
for ENV in qa18 int2
do
	for BRAND in mg pb pk pt we ws
	do
		POM=$(getpom $BRAND $ENV)	
		key=$(grep -i RemoteContentArchiveUrlBases $POM | awk -F '[<>]' '{ print $2 }')

		#propset -f $POM -p $key -v "$NV"
		update $BRAND $ENV deploy #>/dev/null 2>&1 &
	done
done
