#!/bin/sh

HEADER="# Host, IP, JDK Link, Installed JDKs"
DATE=$(date +'%Y-%m-%d')

NODES_NONPRD=apm-inventory-nonprd.nodes

OUT_NONPRD="apm-inventory-nonprd.txt"
touch $OUT_NONPRD

pingTest(){
    ping -c 2 $1  >/dev/null 2>&1 
}

for node in $(cat $NODES_NONPRD)
do
    pingTest $node || continue
    IP=$(host $node |grep -i address | awk '{ print $NF}')

    SSH="sshpass -e ssh -q $SSHOPTS ${SSHUSER}@$node"
    grep -iq "$node" $OUT_NONPRD || wsikey $node >/dev/null 2>&1 

    cat $OUT_NONPRD | grep -iv "$node" > $OUT_NONPRD.new && mv $OUT_NONPRD.new $OUT_NONPRD

    APM=$(ssh -q $node "rpm -qa | grep -i 'wsgc-apm' ")
    [ -z "$APM" ] && continue

    echo "$node,$APM" 
    echo "$node,$APM" >> $OUT_NONPRD
done

git pull
sort -u $OUT_NONPRD >> $OUT_NONPRD.new && mv $OUT_NONPRD.new $OUT_NONPRD
git add $OUT_NONPRD >/dev/null 2>&1
git commit -m "Updated results" $OUT_NONPRD >/dev/null 2>&1
git push >/dev/null 2>&1

