#!/bin/sh

BRAND=pb
DST_ENV=qa9
SRC_ENV=qa10
ITEMS=/wsgc/mead/r1-sku.txt

BailOut() {
	[ -n "$1" ] && echo "$*"
	echo "Usage: $(basename $0) <brand> <dst_env> <src_env> [commit]"
}
alias sqlplus="DYLD_LIBRARY_PATH=~/instantclient sqlplus"

SRC_DB=$(getdb $(getschema $BRAND $SRC_ENV))
[ -z "$SRC_DB" ] && BailOut "Can't get creds for $$BRAND $SRC_ENV"
DST_DB=$(getdb $(getschema $BRAND $DST_ENV))
[ -z "$DST_DB" ] && BailOut "Can't get creds for $BRAND $DST_ENV"

SRC_dbHost=$(echo "$SRC_DB" | awk -F\| '{ print $1 }')
SRC_dbOwner=$(echo "$SRC_DB" | awk -F\| '{ print $2 }')
SRC_dbUser=$(echo "$SRC_DB" | awk -F\| '{ print $3 }')
SRC_dbPass=$(echo "$SRC_DB" | awk -F\| '{ print $4 }')
SRC_dbSID=$(echo "$SRC_DB" | awk -F\| '{ print $5 }')
SRC_dbPort=$(echo "$SRC_DB" | awk -F\| '{ print $6 }')
SRC_dbTable=$(echo "$SRC_DB" | awk -F\| '{ print $7 }')

DST_dbHost=$(echo "$DST_DB" | awk -F\| '{ print $1 }')
DST_dbOwner=$(echo "$DST_DB" | awk -F\| '{ print $2 }')
DST_dbUser=$(echo "$DST_DB" | awk -F\| '{ print $3 }')
DST_dbPass=$(echo "$DST_DB" | awk -F\| '{ print $4 }')
DST_dbSID=$(echo "$DST_DB" | awk -F\| '{ print $5 }')
DST_dbPort=$(echo "$DST_DB" | awk -F\| '{ print $6 }')
DST_dbTable=$(echo "$DST_DB" | awk -F\| '{ print $7 }')


#select  * from DTCMOU_APP_OWNER.WW_ITEMS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_DIFFS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_PRICES where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_SELLING_FLAGS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_SELLING_SERVICES where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VARIANT_PRICES where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VAS_COLORS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VAS_DETAILS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VAS_LIMITS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VAS_LOCATIONS where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_ITEM_VAS_STYLES where ITEM_ID='4241378';
#select  * from DTCMOU_APP_OWNER.WW_INVENTORY_STATE where SKU='4241378';
#Update R1_APP_OWNER.WW_ITEM_PRICES set PRICE_END_TIME=null where ITEM_ID='4241378';

for SKU in $(cat $ITEMS) 
do
	for TABLE in WW_ITEMS WW_ITEM_DIFFS WW_ITEM_PRICES WW_ITEM_SELLING_FLAGS WW_ITEM_SELLING_SERVICES WW_ITEM_VARIANT_PRICES WW_ITEM_VAS_COLORS WW_ITEM_VAS_DETAILS WW_ITEM_VAS_LIMITS WW_ITEM_VAS_LOCATIONS WW_ITEM_VAS_STYLES WW_INVENTORY_STATE 
	do
		key="ITEM_ID"
		[ "$TABLE" = "WW_INVENTORY_STATE" ] && key="SKU"

#		I="set heading off;
#insert into ${DST_dbOwner}.$TABLE 
#(CONCEPT_CODE,ITEM_TYPE_CODE,ITEM_NAME,ITEM_SHORT_NAME,ITEM_MEDIUM_NAME,$key) VALUES ('$CONCEPT_CODE','$ITEM_CODE','$ITEM_NAME','$ITEM_SHORT_NAME','ITEM_MEDIUM_NAME',$SKU);"

		#echo "$I"
		#echo "$I" | sqlplus -S ${DST_dbUser}/${DST_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${DST_dbHost})(PORT=${DST_dbPort}))(CONNECT_DATA=(SID=${DST_dbSID})))"

		C="set heading off;
select distinct COLUMN_NAME from all_tab_cols where table_name='$TABLE';	"
		for col in $(echo "$C" | sqlplus -S ${SRC_dbUser}/${SRC_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${SRC_dbHost})(PORT=${SRC_dbPort}))(CONNECT_DATA=(SID=${SRC_dbSID})))" | egrep -iv "rows selected|^$|SYS_|tr -d '\n' ")
		do
			[ -n "$COLUMNS" ] && COLUMNS="$COLUMNS,"
			COLUMNS="$COLUMNS$col"
		done
echo "$COLUMNS"

		I="set heading off;
insert into ${DST_dbOwner}.$TABLE 
	($COLUMNS)
with copy_env as 
	(select $COLUMNS from ${DST_dbOwner}.$TABLE where $key='$SKU')
SELECT $COLUMNS
from copy_env;
;
"

		echo "$I"
		echo "$I" | sqlplus -S ${DST_dbUser}/${DST_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${DST_dbHost})(PORT=${DST_dbPort}))(CONNECT_DATA=(SID=${DST_dbSID})))"

exit
		for col in $(echo "$C" | sqlplus -S ${SRC_dbUser}/${SRC_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${SRC_dbHost})(PORT=${SRC_dbPort}))(CONNECT_DATA=(SID=${SRC_dbSID})))" | egrep -iv "^$|rows selected|SYS_")
		do
			D="set heading off;
select distinct $col from ${SRC_dbOwner}.$TABLE where $key='$SKU';"

			#echo "$D"
			#echo "$D" | sqlplus -S ${SRC_dbUser}/${SRC_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${SRC_dbHost})(PORT=${SRC_dbPort}))(CONNECT_DATA=(SID=${SRC_dbSID})))"

			VALUE=$(echo "$D" | sqlplus -S ${SRC_dbUser}/${SRC_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${SRC_dbHost})(PORT=${SRC_dbPort}))(CONNECT_DATA=(SID=${SRC_dbSID})))" \
| egrep -iv "rows selected" \
| dos2unix \
| tr -d '\n' \
)
			[ -z "$VALUE" ] && continue	
			#echo "$TABLE $col $SKU [$VALUE]"

			U="UPDATE $TABLE set $col = '$VALUE' where $key='$SKU';"
			echo "$U"
			#echo "$U" | sqlplus -S ${DST_dbUser}/${DST_dbPass}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${DST_dbHost})(PORT=${DST_dbPort}))(CONNECT_DATA=(SID=${DST_dbSID})))")
				
		done
	done
done

