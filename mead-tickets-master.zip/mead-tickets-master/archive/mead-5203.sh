# copy app settings from one env to another
BRANDS="ws"
ENV="qa17"
NEW_DB=webqa2/dtcmou_app_owner

MEAD=$(basename $0 | tr "A-Z" "a-z" | sed -e s/[a-z]//g | sed -e s/-//g | sed -e s/\.$//g)
MSG="copy $BRANDS $ENV appsettings from $OLD_DB to $NEW_DB"
TMP=/wsgc/mead/mead-$MEAD.save

cd /wsgc/svn/devops/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site
#svn cleanup
svn up
[ "$ENV" = "rgs1" ] && ENV="regression"
[ "$ENV" = "rgs2" ] && ENV="regression2"

for b in $BRANDS
do
	[ -z "$OLD_DB" ] && OLD_DB=$(geturls $b $ENV|grep -i override | awk -F/ '{ print $(NF-4) "/" $(NF-3) }')
	OLD_DIR=$OLD_DB/$b/override
	NEW_DIR=$NEW_DB/$b/override

	PROPS=/tmp/properties-$ENV-$b
	mkdir -p $TMP

	[ -f $TMP/override.properties.$b ] || cp $NEW_DIR/override.properties $TMP/override.properties.$b

	# seed the new file with the existing properties from the new schema
	cat $NEW_DIR/override.properties > $PROPS
	echo >> $PROPS

	# add the properties for $ENV to the newly seeded file
	cat $OLD_DIR/override.properties | egrep -i "\.$ENV\." | egrep -vi "^#" | sort -u >> $PROPS

	#ls -l $PROPS
	diff $NEW_DIR/override.properties $PROPS

	#cp $PROPS $NEW_DIR/override.properties
	ls -l $NEW_DIR/override.properties
done

svn commit -m "[MEAD-$MEAD] $MSG"

cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk
svn up

SRC=qa10
for BRAND in $BRANDS
do
	MSG="copy $BRAND $ENV db settings from $SRC"
	DST_POM=$(getpom $BRAND $ENV)
	SRC_POM=$(getpom $BRAND $SRC)

	for prop in frontend.datasource.session.url frontend.datasource.session.username frontend.datasource.session.password frontend.datasource.ecomDB.url frontend.datasource.ecomDB.username frontend.datasource.ecomDB.password frontend.tableOwner
	do
	        propcopy -f $DST_POM -p $prop -s $SRC_POM
	done
	svn commit -m "[MEAD-$MEAD] $MSG"
done


