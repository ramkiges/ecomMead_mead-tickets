PERF=perf2
OVERRIDE=src/main/resources/httpd/conf.d/frontend.conf.override
for b in mg pb pk pt we ws
do
	cd /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk/$b/$PERF
	pwd
	set -x
	svn mkdir --parents $(dirname $OVERRIDE)
	#cp /wsgc/frontend.conf.override $OVERRIDE
	#svn commit -m "[DEVOPS] added frontend.conf.override for ancient version of apache"
	set +x
	set-svn-textprop $OVERRIDE
	jenkins build wsgc-devops-frontend21-qa-single-env -p BRAND=$b -p ENVIRONMENT=$PERF	
	echo
done
