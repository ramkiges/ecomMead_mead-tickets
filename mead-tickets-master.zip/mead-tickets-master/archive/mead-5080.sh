
ENV=qa9
TEMPLATE="/tmp/uitests-template.xml"
RECIPIENTS=
DESCRIPTION="special test suite" 
NS="http://maven.apache.org/POM/4.0.0"
TESTS_1="com.wsgc.ecom.uitests.shop.nextgenpip.simplepip.**"
TESTS_2="com.wsgc.ecom.uitests.registry.additem.nextgenpip.**"

cd /Users/tfitzpatrick/wsgc/svn/jenkins-jobs/evergreen

git pull

for BRAND in mg pb pk pt we ws
do
	JOB="uitests-$ENV-netgenpip-$BRAND.xml"

	cat $TEMPLATE | \
sed \
-es=BRAND=$BRAND=g \
-es=ENV=$ENV=g \
-es="TESTS_1"="$TESTS_1"=g \
-es="TESTS_2"="$TESTS_2"=g \
-es="<disabled>.*</disabled>"="<disabled>false</disabled>"=g \
-es="<blockingJobs>.*</blockingJobs>"="<blockingJobs>deploy-$ENV-$BRAND-WAR\.*</blockingJobs>"=g \
-es=DESCRIPTION="$DESCRIPTION"=g \
-es="<spec>.*</spec>"="<spec></spec>"=g \
-es="<recipients>.*</recipients>"="<recipients>$RECIPIENTS</recipients>"=g \
> $JOB

git add $JOB

done
#-es="<projects>.*</projects>"="<projects></projects>"=g \
