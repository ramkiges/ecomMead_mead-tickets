# copy app settings from one env to another
BRANDS="we"
ENV="qa8"
NEW_DB=webqa1/r1_app_owner
OLD_DB=webqa2/dtc_app_owner

MEAD=$(basename $0 | tr "A-Z" "a-z" | sed -e s/[a-z]//g | sed -e s/-//g | sed -e s/\.$//g)
TMP=/wsgc/mead/mead-$MEAD.save

cd /wsgc/svn/devops/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site
#svn cleanup
svn up
[ "$ENV" = "rgs1" ] && ENV="regression"
[ "$ENV" = "rgs2" ] && ENV="regression2"

for b in $BRANDS
do
	[ -z "$OLD_DB" ] && OLD_DB=$(geturls $b $ENV|grep -i override | awk -F/ '{ print $(NF-4) "/" $(NF-3) }')
	if [ -z "$OLD_DB" ]
	then
		echo "Can't figure out old DB"
		exit 1
	fi
	OLD_DIR=$OLD_DB/$b/override
	NEW_DIR=$NEW_DB/$b/override

	PROPS=/tmp/properties-$ENV-$b
	mkdir -p $TMP

	[ -f $TMP/override.properties.$b ] || cp $NEW_DIR/override.properties $TMP/override.properties.$b

	# seed the new file with the existing properties from the new schema
	cat $NEW_DIR/override.properties > $PROPS
	echo >> $PROPS

	# add the properties for $ENV to the newly seeded file
	cat $OLD_DIR/override.properties | egrep -i "\.$ENV\." | egrep -vi "^#" | sort -u >> $PROPS

	ls -l $PROPS
	#diff $NEW_DIR/override.properties $PROPS

	cp $PROPS $NEW_DIR/override.properties
	#ls -l $NEW_DIR/override.properties
done

MSG="copy $BRANDS $ENV appsettings from $OLD_DB to $NEW_DB"
svn commit -m "[MEAD-$MEAD] $MSG"

