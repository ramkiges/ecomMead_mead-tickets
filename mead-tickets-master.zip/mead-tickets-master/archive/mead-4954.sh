#!/bin/sh

for b in mg pb pk pt we ws
do
	host=$(geturls $b qa17 | grep -i "host:" | awk '{ print $NF }')
	echo
	echo $host
	echo "<!-- $b -->"
	#ssh -q $host "grep -i braintree /apps/tomcat/conf/Catalina/localhost/ROOT.xml"
	update $b qa6 deploy >/dev/null 2>&1 &
done
