#!/bin/sh

#### Script to configure Auto merge in scm-tools repo ####

USER='sganesh1'
PWD='git token or password'
GIT_REPO="https://$USER:$PWD@github.wsgc.com/eCommerce-DevOps/scm-tools.git"
NEW_SHRTCUT='checkout-redesign-wrk-190313-shortcut'
TRUNK='trunk-shortcut'
MEAD='MEAD-8160'
echo "Cloning the scm-tools repo"
#echo "$GIT_REPO"
cd /home/a_sganesh1/workspace/works/sg
git -c http.sslVerify=false clone $GIT_REPO
cd scm-tools
echo "Current branch is $(git branch | awk '{print $2}') "
echo "creating local branch"
git checkout -b "$MEAD"

echo "Current branch is $(git branch | awk '{print $2}') "

if [ -f data/merges.daily.txt ]
then
   echo "$TRUNK -> $NEW_SHRTCUT" >> data/merges.daily.txt
   git add data/merges.daily.txt
   git commit -m "[$MEAD] adding $NEW_SHRTCUT"
   git config http.sslVerify false
   git push --set-upstream origin $MEAD
   echo "git $MEAD branch push completed, please raise a PR in GHE"
else 
   echo "merges.daily txt not found"
   exit 1
fi

rm -rf *
