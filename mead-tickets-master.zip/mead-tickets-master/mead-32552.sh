#!/bin/sh
# this script is for setting up Akamai in a frontend environment
# creates 2 CSV files to be submitted in SNOW tickets:
# $TICKET-cnames.csv - submit to get CNAMES created
# $TICKET-vips.csv - submit to get VIPS created

ENV_LIST="qa41"

# secure-qa  to get a legitimate akamai cert 
# secure-qa2 for a legitimate cert for canada
# secure-qa1 for everything else
EDGE=secure-qa

TICKET=$(basename $0 | tr '[:upper:]' '[:lower:]' | sed -es/\.sh//g)

BailOut() {
    [ -n "$1" ] && echo "$*"
    exit 1
}

[ -z "$ENV_LIST" ] && BailOut "ENV_LIST can't be blank"
CNAMES=$TICKET-cnames.csv
VIPS=$TICKET-vips.csv
rm -f $CNAMES $VIPS

echo "Please update the following CNAMEs in DNS" > $CNAMES
echo >> $CNAMES

for e in $ENV_LIST
do
  for b in $(getbrandlist $e)
  do
    a=$(get-akamai $b $e | awk -F/ '{ print $3 }')
    [[ $tld = "ca" ]] && a=$(echo "$a" | sed -es/"^ca"//g)
    echo "$a,IN CNAME,$EDGE.wsgc.com.edgekey.net" >> $CNAMES
  done
done

echo >> $CNAMES
echo "Jira: https://jira.wsgc.com/browse/$TICKET" >> $CNAMES
echo >> $CNAMES

echo "Please create the following A records in DNS and VIPs on the F5 load balancers; you can model these on the existing QA VIPs.  Use the 'Sitecode_ignore' node health rule for the VIPs" > $VIPS
echo >> $VIPS

echo "A records/VIPS,,,Node,Ports" >> $VIPS
for e in $ENV_LIST
do
  for b in $(getbrandlist $e)
  do
    a=$(get-akamai $b $e | awk -F/ '{ print $3 }')
    tld=$(echo "$a" | awk -F\. '{ print $NF }')
    [[ $tld = "ca" ]] && a=$(echo "$a" | sed -es/"^ca"//g)

    alias=$(get-host $b $e)
    [ -z "$alias" ] && BailOut "CNAME not found for $b $e"
    host=$(host $alias | grep -i address | awk '{ print $1 }')

    echo "vip_${e}_${b}_${tld},IN A,origin-${a},${host},80 49446" >> $VIPS
    done
done
echo >> $VIPS
echo "Jira: https://jira.wsgc.com/browse/$TICKET" >> $VIPS
echo >> $VIPS

echo $CNAMES $VIPS
git add $CNAMES $VIPS $0
git commit -a -m "[$TICKET] commit CNAME and VIP request files"
git push

jira-comment $TICKET "{noformat:title=CNAMEs for $ENV_LIST}$(cat $CNAMES){noformat}"
jira-comment $TICKET "{noformat:title=VIPs for $ENV_LIST}$(cat $VIPS){noformat}"

